package com.informive.bridgewire.http

import javax.servlet.http.{HttpServletResponse, HttpServletRequest}
import scala.concurrent.{Future, ExecutionContext}
import scala.concurrent.{Promise => AkkaPromise}

// BridgeWire Imports
import redis.clients.jedis.Jedis
import com.informive.bridgewire.{BridgeWire_Config => BWC}
import java.net.{ConnectException}
import scala.collection.JavaConversions._
import com.mchange.v2.c3p0.ComboPooledDataSource
import com.informive.bridgewire.database.postgresql.{DbNormalConnection, DbAdminConnection}
import java.sql.{Timestamp, Connection => C, Statement => S, ResultSet => RS}
import org.fusesource.scalate.util.Logging

class RegisterClientRecorder extends Logging with DbNormalConnection {
  private val redisUri = BWC.Redis.uri_Rec1
  private var jedis: Jedis = _

  try {
    jedis = new Jedis(redisUri)
    println("JEDIS has opened a connection to REDIS server:" + redisUri)
  } catch {
    case ce: ConnectException => {
      println("BridgeWire could not create a connection to REDIS server.")
    }
    case e: Exception => {
      println("ConnectException while trying to create a connection to REDIS.")
      e.printStackTrace()
    }
  }

  def register(request: HttpServletRequest, response: HttpServletResponse): String = {
    val sessionID:String = java.util.UUID.randomUUID.toString
    var output:String = ""
    val SID:String = request.getParameter("SID")
    var sql:String = ""
    var c: C = null
    var s: S = null

    println("SID request: " + SID)
    println("Recorder SessionID: " + sessionID)

    try {
      c = genericCpds.getConnection()
      s = c.createStatement()
      sql = "INSERT INTO recorded_session (site_id, session) " +
            "SELECT id, '" + sessionID + "' " +
            "FROM recorded_site " +
            "WHERE guid = '" + SID + "'"

      println(sql)

      s.executeUpdate(sql)
    } catch {
      case e:Exception => {
        error("ClientRegister OLAP database error: " + e.toString())
      }
    } finally {
      s.close()
      c.close()
    }

    // TODO: wrap REDIS calls in try/catch (look for missed/invalid key requests)
    // TODO: redo "recorded_site" to include these site-based settings:

    val originIP:String = request.getRemoteAddr().toString()
    val originPort:String = request.getRemotePort().toString()
    val siteName:String = jedis.get("sites:" + SID + ":name")               // GUID for the Site (account ID)
    val connLimit:String = jedis.get("sites:" + SID + ":connLimit")         // max number of concurrent recording sessions
    val connCount:String = jedis.get("sites:" + SID + ":connCount")         // current number of recording sessions
    val timeLimit:String = jedis.get("sites:" + SID + ":timeLimit")         // time limit of each recording session
    val recordFile:String = jedis.get("sites:" + SID + ":recordFile")       // allow dynamic file points (based on business intelligence
    val loadState:String = jedis.get("sites:" + SID + ":loadState")         // BridgeWire state upon loading

    // TODO: calculate these by logic:

    // TODO: logic to determine if connection is allowed (within connLimit boundary)
    val redisIP:String = "127.0.0.1"                                        // tells NODE which ** DB ** server to use (logic based)

    // TODO: create a long-polling NODE server for browsers w/o Websocket integration
    val nodeIP:String = "192.168.0.150"                                     // tells CLIENT which ** WEBSOCKET ** server to use (logic based)


    // TODO: create DOS filter for request(s) based upon IP
    println("New RECORD Session requested: " + originIP + ":" + originPort)

    // Test to make sure the session is within the connLimit boundary
    if(connCount.toInt >= connLimit.toInt) {
      println("Connection Limit Reached")
    } else {
      // TODO: if a recording is not started, these values will not be set w/i the client...make sure that ctrl-alt-Information can handle an empty set
      println("New RECORD Session stub created: " + sessionID)
      jedis.set("record:" + sessionID + ":timeLimit", timeLimit)
      jedis.set("record:" + sessionID + ":redisIP", redisIP)
      jedis.set("record:" + sessionID + ":nodeIP", nodeIP)
      jedis.set("record:" + sessionID + ":origin", originIP + ":" + originPort)

      // TODO: insert recordFile as JSON REC_CONFIG: jedis.set("record:" + sessionID + ":recordFile", recordFile)
      // TODO: create a DB table for the aforementioned JSON-based recording settings (store whole thing in Postgres)

      output = "{" +
        "\"wsIP\":\"" + nodeIP + "\"," +
        "\"sessionID\":\"" + sessionID + "\"," +
        "\"recTimeLimit\":\"" + timeLimit + "\"," +
        "\"settings\":{}" +
        "}"
    }
    return output
  }
}