package com.informive.bridgewire.database

import scala.concurrent.{Future, ExecutionContext}
import scala.concurrent.{Promise => AkkaPromise}
import akka.actor.Actor
import ExecutionContext.Implicits.global
import java.util.concurrent._
import scala.util.control.Breaks._
import org.fusesource.scalate.util.Logging

// BridgeWire Imports
import redis.clients.jedis.Jedis
import com.informive.bridgewire.{BridgeWire_Config => BWC}
import java.net.{ConnectException}
import scala.collection.JavaConversions._
import com.mchange.v2.c3p0.ComboPooledDataSource
import com.informive.bridgewire.database.postgresql.{DbNormalConnection, DbAdminConnection}
import java.sql.{Timestamp, Connection => C, Statement => S, ResultSet => RS}


/*
  This Actor is designed to periodically move the record-data entries out of a given REDIS cache (OLTP) and into
  Postgres (OLAP) for analytic processing.
 */

class RedisRecordedEventSweeper extends Actor with Logging with DbNormalConnection
{
  // implicit val defaultDatasource = genericCpds
  private val redisUri = BWC.Redis.uri_Rec1
  private var jedis: Jedis = _

  try {
    jedis = new Jedis(redisUri)
    info("RedisRecordedEventSweeper has opened a connection to REDIS server:" + redisUri)
  } catch {
    case ce: ConnectException => {
      info("RedisRecordedEventSweeper could not create a connection to REDIS server")
    }
    case e: Exception => {
      info("RedisRecordedEventSweeper 'ConnectException' while trying to connect to REDIS")
      e.printStackTrace()
    }
  }

  override def preStart() {
    info("RedisRecordSweeper preStart()")
  }

  def receive = {
    case "run" => {
      println("RedisRecordSweeper 'run' called")

      // get all of the recorded events current in the cache (Redis)
      val keys = jedis.keys("recData:*")
      var sql: String = ""

      keys.foreach{ key =>
        val value:String = jedis.get(key)
        val tokens = key.split(":")
        val sessionId = tokens(1)
        var c: C = null
        var s: S = null

// TODO: get the site ID (for dynamic assignment, instead of hardcoded value of "1")
        sql = "INSERT INTO recorded_event_json (session_id, event) " +
              "SELECT id, '" + value + "' " +
              "FROM recorded_session " +
              "WHERE session = '" + sessionId + "' AND site_id = 1"
        try {
          c = genericCpds.getConnection()
          s = c.createStatement()

          println(sql)

          s.executeUpdate(sql)
        } catch {
          case e:Exception => {
            error("getFormattedRecord() using (" + sql.toString + ") Error: " + e.toString())
          }
        } finally {
          s.close()
          c.close()
        }

        jedis.del(key)
      }
    }

    case _ => {
      info("RedisRecordSweeper received an unrecognized message")
    }
  }

  override def postStop() {
    info("RedisRecordSweeper postStop()")
  }
}


