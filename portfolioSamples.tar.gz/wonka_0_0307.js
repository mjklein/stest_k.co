/********************************************************************************************************************
**
**    Wonka(tm) Software Library
**    Version: 0.03.07
**
**    Copyright 2013-2014  Informive Corporation
**    ALL RIGHTS RESERVED
**    __________________________________________
**
**    NOTICE: This software library is the exclusive property of Informive Corporation and may not be copied,
**    modified, redistributed or otherwise reproduced in any form or manner without the express written consent of
**    Informive Corporation.
**
**    Wonka and Informive are the protected trademarks of Informive Corporation.
**
**    For questions or issues pertaining to this software library, contact us via email at Legal@Informive.com
**
********************************************************************************************************************/


if(typeof Wonka == 'undefined') {
  Wonka = {
    v0_0307: {
      version: "0_0307",
      Defaults: {}
    }
  }
}

// register by name, versionReference
LR.regLibrary("Wonka", Wonka.v0_0307)

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                Frame

Description: A generic container that is pre-wired for event processing activities
Output Events:
Input/Pipeline Events:

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

Wonka.v0_0307.Defaults.Frame = {
  bubble: {
    classNames: {                                         // when BUBBLE.MODE is set to "classnames", the following will be applied to the "default" element
      normal: undefined,
      active: undefined,
      disabled: undefined,
      mouseover: undefined,
      mousedown: undefined
    },
    customRenderDelegate: undefined,                        // when defined, this method will be called to custom-handle the backdrop rendering
    default: undefined,                                     //    undefined = REMOVES BUBBLE
    elements: {                                             // {undefined, "default", "[element_id]"} ...
      normal: "default",
      active: "default",                                    //    "default" = uses the "default" bubble
      disabled: "default",                                  //    [other] = element reference to be used instead
      mouseover: "default",
      mousedown: "default"
    },
    updateMode: undefined                                         // {undefined, "element", "classname"} - to use ELEMENTS, CLASSNAMES, or nothing (no bubble)
  },
  content: {
    classNames: {                                         // when BUBBLE.MODE is set to "classnames", the following will be applied to the "default" element
      normal: undefined,
      active: undefined,
      disabled: undefined,
      mouseover: undefined,
      mousedown: undefined
    },
    customRenderDelegate: undefined,                        // when defined, this method will be called to custom-handle the content rendering
    elements: {                                             // {undefined, "default", "[element_id]"} ...
      normal: "default",
      active: "default",                                    //    "default" = uses the "default" bubble
      disabled: "default",                                  //    [other] = element reference to be used instead
      mouseover: "default",
      mousedown: "default"
    },
    updateMode: undefined                                         // {undefined, "element", "classname"} - to use ELEMENTS, CLASSNAMES, or nothing (no bubble)
  },
  control: {
    container: undefined,
    content: undefined,                                       // reference to content (HTML) element
    enabled: true,                                            // TODO
    mode: "div",                                             // {"inline", other} attach to existing element, or create a new element (as defined)
    tabIndex: undefined,
    visible: true
  },
  events: {                                                 // {TRUE, undefined, delegate, "custom event"} determines the events fired, and the handlers (optional)
    dom: {
      mouseover: undefined,                                   //    TRUE = monitor (internally)
      mouseout: undefined,                                    //    undefined = ignore
      click: undefined,                                       //    delegate = pass event to delegated method for processing
      mousedown: undefined,                                   //    custom event = fires an custom event as defined by "EVENT_FOO"
      mouseup: undefined
    },
    pipes: {
      send: [],                                             // presence of EMTPY Array() means to use default (same as "default"), undefined = no SEND events
      receive: []
    },
    processor: undefined                                   // custom event processor (function reference)
  }
}

Wonka.v0_0307.Frame = function(controlId, instSettings, templateSettings) {
  var defaultSettings = Wonka.v0_0307.Defaults.Frame
  var objectClass = "Frame"
  this.settings = LR.util.stackSettings(instSettings, templateSettings, defaultSettings)

  this.controlId = controlId
  this.ctrlElement = undefined                  // the top-level HTML element of this control
  this.eventHandler = undefined                 // placeholder
  this.pipeline = undefined
  this.state = undefined                        // normal, active, hot, engaged, disabled
  this.bubbleElement = undefined                // ref. handle to the bubble element (optional)
  this.bubbleParentReference = undefined        // holds a pointer the "previous" bubble parent (used for resetting)

  var self = this
  var $ = self.settings

  function getDefaultSettings() {
    return self.defaultSettings
  }

  this.show = function() {
    var F = undefined
    var f = undefined

    if($.mode == "inline") {
      // inline is used when the HTML element is/was already defined within the UI layout and therefore a "new" UI component
      // does not need to be created.
      // TODO
    } else {
      // create a new Frame UI element (as per mode definition)
      f = document.createElement($.control.mode)
      f.id = self.controlId
      if($.control.tabIndex != undefined) {
        f.tabIndex = $.control.tabIndex
      }

// TODO: different initial state
      f.className = $.frame.classNames.normal
      self.state = "normal"

      // re-align content (if defined)
      if($.frame.elements.normal != undefined) {
        f.appendChild($.frame.elements.normal)
      }
      self.ctrlElement = F = $.control.container.appendChild(f)
    }

    if($.control.enabled) {
      self.enable()
    } else {
      self.disable()
    }
  }

// TODO: incorporate logic to handle delegate instead of internal (event handler)
  this.enable = function() {
    var handler = self.eventHandler

    // control.className = control.getAttribute("data-class") + "_enabled"
    if($.events.dom.mouseover != undefined) {
      self.ctrlElement.addEventListener("mouseover", handler, false)
    }
    if($.events.dom.mouseout != undefined) {
      self.ctrlElement.addEventListener("mouseout", handler, false)
    }
    if($.events.dom.mousedown != undefined) {
      self.ctrlElement.addEventListener("mousedown", handler, false)
    }
    if($.events.dom.mouseup != undefined) {
      self.ctrlElement.addEventListener("mouseup", handler, false)
    }
    if($.events.dom.click != undefined) {
      self.ctrlElement.addEventListener("click", handler, false)
    }
  }

  this.disable = function() {
    var handler = self.eventHandler
    self.ctrlElement.removeEventListener("mouseover", handler, false)
    self.ctrlElement.removeEventListener("mouseout", handler, false)
    self.ctrlElement.removeEventListener("mousedown", handler, false)
    self.ctrlElement.removeEventListener("mouseup", handler, false)
  }

  this.pipelineEventProcessor = function (pipeName, event , controlId, srcControl, data) {
  }

  function fireEvent(e) {
    self.pipeline.send(e, undefined)
  }

  this.e_defaultHandler = function (event) {
    var pipeEvent = undefined
    var control = event.target
    var e = event.type
    var suffix = undefined
    switch(e) {
      case "mouseover":
        if($.events.dom.mouseover == true) { // "TRUE" means to process (internally)
          // act according to frame (and bubble) mode(s):
          if($.frame.updateMode != undefined) {
            if(($.frame.updateMode == "element") && (true)) {
              // change frame elements
// TODO: swap content elements
            } else if(($.frame.updateMode == "classname") && ($.frame.classNames.mouseover != undefined)) {
              // change classname of the frame element
              self.ctrlElement.className = $.frame.classNames.mouseover
            } else {
              alert ("Unrecognized 'frame.updateMode' for <control name>!")
            }
          }

          // bubble processing
          if($.bubble.updateMode != undefined) {
            if($.bubble.updateMode == "element") {
              // ALWAYS check, an "undefined" bubble event = erase
              if($.bubble.elements.mouseover == undefined) {
                self.bubbleParentReference.removeChild(self.bubbleElement)
                self.bubbleParentReference = undefined
              } else {
                self.bubbleParentReference = $.bubble.elements.mouseover.parentElement
                self.bubbleElement = self.ctrlElement.appendChild($.bubble.elements.mouseover)
              }
            } else if(($.bubble.updateMode == "classname") && ($.bubble.classNames.mouseover != undefined)) {
              // change classname of the frame element
              self.bubbleElement.className = $.bubble.classNames.mouseover
            } else {
              alert ("Unrecognized 'bubbleElement.updateMode' for <control name>!")
            }
          }
        } else {
          // anything else is interpreted as a custom EVENT (string)
          fireEvent($.events.mouseover)
        }
        break;
      case "mousedown":

        break;
      case "mouseup":

        break;
      case "mouseout":
        if($.events.dom.mouseout == true) {
          // "TRUE" means to process (internally)
          // act according to frame (and bubble) mode(s):
          if($.frame.updateMode != undefined) {
            if(($.frame.updateMode == "element") && (true)) {
              // change frame elements
// TODO
            } else if($.frame.updateMode == "classname") {
              // change classname of the frame element to the appropriate state
              if(self.state == "normal") {
                // NORMAL
                self.ctrlElement.className = $.frame.classNames.normal
              } else {
                // ACTIVE
                self.ctrlElement.className = $.frame.classNames.active
              }
            } else {
              alert ("Unrecognized 'frame.updateMode' for <control name>!")
            }
          }

          // bubble processing
          if($.bubble.updateMode != undefined) {
            if($.bubble.updateMode == "element") {
              // ALWAYS check, an "undefined" bubble event = erase
              if($.bubble.elements.mouseout == undefined) {
                if(self.bubbleParentReference != undefined) {
                  self.bubbleParentReference.appendChild(self.bubbleElement)
                  self.bubbleParentReference = undefined
                 }
              } else {
                self.bubbleParentReference = $.bubble.elements.mouseout.parentElement
                self.bubbleElement = self.ctrlElement.appendChild($.bubble.elements.mouseout)
              }
            } else if(($.bubble.updateMode == "classname") && ($.bubble.classNames.mouseout != undefined)) {
              // change classname of the frame element
              self.bubbleElement.className = $.bubble.classNames.mouseout
            } else {
              alert ("Unrecognized 'bubbleElement.updateMode' for <control name>!")
            }
          }

        } else {
          // anything else is interpreted as a custom EVENT (string)
          fireEvent($.events.mouseover)
        }
        break;
    }
    // button.className = event.target.getAttribute("data-class") + suffix
  }

  this.load = function() {
    self.pipeline = new LR.sys.PipelineInterface(self, self.pipelineEventProcessor)
    self.eventHandler = ($.eventHandler) ? $.eventHandler : self.e_defaultHandler

    $.control.container = LR.util.resolveEle($.control.container)

    if ($.control.visible) {
      self.show()
      self.ctrlElement.visibility = "display"
    } else {
      self.ctrlElement.visibility = "hidden"
    }

    // *** EVENT
    self.pipeline.send("FRM_Loaded", undefined)
  }
}


/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                  ExButton

Description: This control provides extended button capabilities. These buttons take any elemental-shape, and can trigger
            LogicRail events and/or navigation events.
Output Events:
Input/Pipeline Events:

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

Wonka.v0_0307.Defaults.ExButton = {
  control: {
    className: undefined,                                   // a state-independent mechanism
    container: undefined,
    enabled: true,
    initialState: "normal",
    tabIndex: undefined,
    type: "span",                                           // Control DOM element type
    visible: true,
    fadeInterval: 25,                                        // number of millisecond-interval used in fade transitions
    storageLocation: "WonkaWidgets"
  },
  events: {
    dom: {                                                  // ADD any/all events here (typically: mouseover, mouseout, click)
// TODO: incorporate _TEMPATE_ functionality into events.dom
      _TEMPLATE_: {
        delegate: undefined,
        navAttribute: undefined,
        navLocation: undefined,
        navTarget: undefined,
        pipelineEvents: [],
        state: undefined
      }
    },
    pipes: {
      send: [],
      receive: []
    },
    processor: undefined
  },
  states: {
// TODO: provide a "group" capability for toggle logic (possible by creating a customer container control)
    normal: {
      use: true,
      content: {
        element: undefined,                                 // {UNDEFINED, element.ID, or element reference}  String -> element.id
        literal: undefined,                                 // used to *programmatically* construct the content element
        swap: true                                          // {TRUE, FALSE} t = return to parent, f = leave in place
      },
      classNames: {
        control: undefined,
        content: undefined,
      },
      fadeInDuration: undefined,
      label: undefined                                      // {undefined, "TEXT"} when set, this is the button's label, to erase, set to ""
    },
    selected: {
      use: false,
      content: {
        element: undefined,                                 // {UNDEFINED, element.ID, or element reference}  String -> element.id
        literal: undefined,                                 // used to *programmatically* construct the content element
        swap: true                                          // {TRUE, FALSE} t = return to parent, f = leave in place
      },
      classNames: {
        control: undefined,
        content: undefined,
      },
      fadeInDuration: undefined,
      label: undefined                                      // {undefined, "TEXT"} when set, this is the button's label
    },
    disabled: {
      use: false,
      content: {
        element: undefined,                                 // {UNDEFINED, element.ID, or element reference}  String -> element.id
        literal: undefined,                                 // used to *programmatically* construct the content element
        swap: true                                          // {TRUE, FALSE} t = return to parent, f = leave in place
      },
      classNames: {
        control: undefined,
        content: undefined,
      },
      fadeInDuration: undefined,
      label: undefined                                      // {undefined, "TEXT"} when set, this is the button's label
    },
    hot: {
      use: false,
      content: {
        element: undefined,                                 // {UNDEFINED, element.ID, or element reference}  String -> element.id
        literal: undefined,                                 // used to *programmatically* construct the content element
        swap: true                                          // {TRUE, FALSE} t = return to parent, f = leave in place
      },
      classNames: {
        control: undefined,
        content: undefined,
      },
      fadeInDuration: undefined,
      label: undefined                                      // {undefined, "TEXT"} when set, this is the button's label
    }

/*    EXAMPLE object extension with an additional/custom state definition; could be used for states such as "hidden" or "depressed"
    _LR_TEMPLATE_: {     // TODO: this name designates an extensible-block template (all fields need to be included if optionally defined)
      use: true,                                            // if optionally defined, it'll be there for a reason! (hence, use = true)
      content: {
        element: undefined,                                 // {UNDEFINED, element.ID, or element reference}  String -> element.id
        literal: undefined,                                 // used to *programmatically* construct the content element
        swap: true                                          // {TRUE, FALSE} t = return to parent, f = leave in place
      },
      controlClassname: undefined,
      contentClassname: undefined,
      label: undefined                                      // {undefined, "TEXT"} when set, this is the button's label, to erase, set to ""
    }
*/
  }
}

Wonka.v0_0307.ExButton = function(controlId, instSettings, templateSettings, hExtensions) {
  var self = this
  var defaultSettings = Wonka.v0_0307.Defaults.ExButton
  var objectClass = "ExButton"
  this.settings = LR.util.stackSettings(instSettings, templateSettings, defaultSettings)

  this.controlId = controlId
  this.ctrlElement = undefined                  // the top-level HTML element of this control
  this.curState = undefined
  this.ctrlContent = undefined                  // reference to DOM element
  this.pipeline = undefined
  this.eventHandler = undefined
  this.freshContent = undefined                 // cases of mouseover and mouseout events by logical
  this.staleContent = undefined

  var $ = this.settings

  function getDefaultSettings() {
    return self.defaultSettings
  }

  function setState(newState) {
    var state = $.states[newState]
    // check the obvious...
    if(!state.use) return
    if(state == self.curState) return
    self.freshContent = state._hContent

    // change the control's classname?
    if((state.classNames) && (state.classNames.control != undefined)) {
      self.ctrlElement.className = state.classNames.control
    }

    // swap content?
    if(state._hContent != undefined) {
      // user fader?
      if(state.fader) {
        // the instance the "appendChild" function is called, it will force a "bounce" in the mouse events...those have
        // to be negated. This is done by using a "stale" pointer and comparing mouse-event sources
        if(self.curState) {
          self.staleState = self.curState
          if(self.curState._hContent) {
            self.staleContent = self.curState._hContent
          }
        }
        // insert new content
        self.ctrlContent = self.ctrlElement.appendChild(state._hContent)
        // fader-in call
        if((state._hContent.style.opacity == "") || (parseFloat(state._hContent.style.opacity) == "0")) {
          state.fader.fadeIn(function() {
              if((self.staleState) && (self.staleState._hContent)) {
                self.staleState._hOriginalParent.appendChild(self.staleState._hContent)
                self.staleState._hContent.style.opacity = 0
              }
            }
          )
        }
      } else {
        // no fader...just immediate content swap
        self.ctrlContent = self.ctrlElement.appendChild(state._hContent)
        if((self.curState) && (self.curState._hContent)) {
          self.curState._hOriginalParent.appendChild(self.curState._hContent)
        }
      }
    }
    // change the content classname?
    if((state.classNames) && (state.classNames._hContent != undefined)) {
      self.ctrlContent.className = state.classNames._hContent
    }
    // change label...
    if(state.label != undefined) {
      self.ctrlContent.innerText = state.label
    }
    self.curState = state
  }

  this.disable = function() {
    setState(self.ctrlElement, false, self.eventHandler)
  }

  this.enable = function() {
    setState(self.ctrlElement, true, self.eventHandler)
  }

  this.pipelineEventProcessor = function (pipeName, event , controlId, srcControl, data) {
  }

  function eventProcess(event) {
    if((self.freshContent) && (event.target != self.freshContent)) return // drop event bouncing
    if((self.staleContent) && (event.fromElement == self.staleContent)) return

// console.log(event)
    var eDef = $.events.dom[event.type]
    if(eDef == undefined) return

    // defer to Delegate FIRST; if delegate returns TRUE the continue with default processing
    if(eDef.delegate != undefined) {
      if(eDef.delegate(self, event)) {
        // delegate has terminated default event handling
        return
      }
    }

    // trigger all listed pipeline events
    if((eDef.pipelineEvents) && (eDef.pipelineEvents.length != 0)) {
      for(var i = 0; i < eDef.pipelineEvents.length; i++) {
        e = eDef.pipelineEvents[i]
        self.pipeline.send(e, undefined)
      }
    }

    // change state
    if(eDef.state != undefined) {
      setState(eDef.state)
    }

    // do any navigation
    if(eDef.navLocation != undefined) {
// TODO: set the "location" propert of "navTarget" (if defined)
      if(eDef.navTarget == undefined) {
        window.location = eDef.navLocation
      } else {
        // some type of target was identified...be that pop-up, iFrame, or otherwise...
// TODO: set the appropriate location value depending upon target type (using navAttribute)
      }
    }


  }

  /*
    as a matter of form, this allows a cleaner segregation of functions than having a self-executing initializer;
    also provides more future flexibility
  */
  this.load = function() {
    if(hExtensions) hExtensions(self)
    self.pipeline = new LR.sys.PipelineInterface(self, self.pipelineEventProcessor)
    self.eventHandler = ($.eventHandler) ? $.eventHandler : self.e_defaultHandler

    var EB = undefined
    var eb = document.createElement($.control.type)

    eb.id = self.controlId

    if($.control.tabIndex != undefined) eb.tabIndex = $.control.tabIndex
    if($.control.className != undefined) eb.className = $.control.className
    $.control.storageLocation = LR.util.resolveEle($.control.storageLocation)

    // attach default listeners. ALL events are passed to the default handler FIRST, and then to a delegate (optional)
    eb.addEventListener("mouseover", eventProcess, false)
    eb.addEventListener("mouseout", eventProcess, false)
    eb.addEventListener("click", eventProcess, false)

    // test value type...
    if (typeof $.control.container == "string") {
      $.control.container = document.getElementById($.control.container)
    } else if (typeof $.control.container != "object") {
      alert("Unknown container setting: " + self.controlId)
    }

    self.ctrlElement = EB = $.control.container.appendChild(eb)

    // create subcontrols, in this case, any Faders used to transition state(s)
    for(var s in $.states) {
      var state = $.states[s]

      // Create the "_hContent" and the "_hParent" references
      // NOTE: "LITERAL" entry supersedes "ELEMENT"
      if(state.use) {
        if(state.content.literal) {
          // insert the literal into the DOM under the WonkaTools element
          var temp = document.createElement("div")
          temp.innerHTML = state.content.literal
          state._hContent = $.control.storageLocation.appendChild(temp.firstChild)
          state._hOriginalParent = state._hContent.parentElement
        } else if(state.content.element) {
          state._hContent = LR.util.resolveEle(state.content.element)
          state._hOriginalParent = state._hContent.parentElement
        }
      }

      // use FADER for state.content??
      if(state.fadeInDuration) {
        var controlDef = {
          controlId: "FDR_" + self.controlId + "_" + s,
          objectConstructor: undefined,
          assembly: {
            library: "Wonka",
            maxLibVersion: undefined,
            minLibVersion: "0_0307",
            controlProto: "Fader"
          },
          getTemplateSettings: function() { return undefined },
          getInstanceSettings: function() { return {
              control: {
//                content: LR.util.resolveEle(state.content),
                content: state._hContent,
              },
              fadeIn: {
                use: (state.fadeInDuration),
                duration: state.fadeInDuration,
                interval: $.control.fadeInterval,
                completedEvents: [],
                completedCallback: undefined,
              },
              pause: {
                allow: false
              }
            }
          }
        }
        state.fader = LR.sys.createControl(controlDef)
      }
    }

    /*
    if($.enabled) {
      self.enable()
    } else {
      self.disable()
    }
    */
    setState($.control.initialState)
    self.pipeline.send("EXBTN_Initialized", undefined)
  }
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                ExpansionBar

Description: Creates a control and "expands" to show an additional content panel as the result of a designated event. The
             part of the control that is always visible is called the "static" section, and the part that is exposed
             is known as the "expanded" section. Both sections are DIVs (with associated styles) and will re-assign
             targeted elements for their respective content. (This means the content can be ANYTHING the is encompassed
             (ie, contained within) a HTML tag - typically a DIV).
Output Events: DPB_Cancel_Click
Input/Pipeline Events:

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

Wonka.v0_0307.Defaults.ExpansionBar = {
  classNames: {                                               // used to set style classes on the main control elements
    static: {
      contracted: undefined,                                  // undefined = not used
      contracting: undefined,                                 // undefined = not used
      expanded: undefined,                                    // undefined = not used
      expanding: undefined                                    // undefined = not used
    },
    dynamic: {
      contracted: undefined,                                  // undefined = not used
      contracting: undefined,                                 // undefined = not used
      expanded: undefined,                                    // undefined = not used
      expanding: undefined                                    // undefined = not used
    }
  },
  control: {
    container: undefined,
    content: {
      static: undefined,
      dynamic: undefined
    },
    enabled: true,                                            // TODO
    showMode: "contracted",                                   // {contract, contracted, expand, expanded}
    tabIndex: undefined,
    visible: true
  },
  events: {
    control: {
      expanded: undefined,
      contracted: undefined
    },
    dom: {
      mouseover: undefined,                                   //    TRUE = monitor (internally)
      mouseout: undefined,                                    //    undefined = ignore
      click: undefined,                                       //    delegate = pass event to delegated method for processing
      mousedown: undefined,                                   //    custom event = fires an custom event as defined by "EVENT_FOO"
      mouseup: undefined
    },
    pipes: {
      send: [],                                             // empty Array (or "default") -> use pipeline for controlID
      receive: []
    },
    processor: undefined                                    // custom event handler method (used to process click, mouseover, blur, etc...)
  },
  expansion: {
    cycle: {
      duration: 250,                                        // number of milliseconds for exp/contract. Use "0" for instantaneous
      interval: 25,                                         // number of milliseconds between each animation step
      type: "linear",                                       // {linear, parabolic, bounce, CUSTOM}
      method: undefined                                     // a delegate method to handle expansion/contraction [TODO]
    },
    dimensionMax: undefined,                                // establish a set size for expansion (undefined = browser auto, any other value will override CSS)
    dimensionMin: 0,
    dimensionScale: "px",                                   // {px, %, ETC} Any valid scale mode...will be appended to dimension setting
    direction: "up"                                         // {up, down, right, left} are the directions for expansion
  },
  triggers: {
    expandOnHot: false,
    expandOnClick: false,
    retractWhenCold: false,
    autoRetract: 0                                          // number of non-interaction milliseconds before auto-contract. (0 = disabled)
  }
}

Wonka.v0_0307.ExpansionBar = function(controlId, instSettings, templateSettings) {
  var defaultSettings = Wonka.v0_0307.Defaults.ExpansionBar
  this.objectClass = "ExpansionBar"
  this.settings = LR.util.stackSettings(instSettings, templateSettings, defaultSettings)

  this.controlId = controlId
  this.ctrlElements = undefined                  // the top-level HTML element of this control
  this.eventHandler = undefined                 // placeholder
  this.pipeline = undefined
  this.transitionState = {}                      // used to hold expansions/contraction data

  this.settings.control.content.dynamic = LR.util.resolveEle(this.settings.control.content.dynamic)
  this.settings.control.content.static = LR.util.resolveEle(this.settings.control.content.static)

  this.de = this.settings.control.content.dynamic             // ref to "dynamic" DOM element
  this.dc = this.settings.classNames.dynamic                  // ref to "dynamic" classnames
  this.se = this.settings.control.content.static              // ref to "static" DOM element
  this.sc = this.settings.classNames.static                   // ref to "static" classnames

  var self = this
  var $ = self.settings

  function setElementParent(parent, newChild) {
    parent.appendChild(newChild);
  }

  this.expand = function(cDuration,cInterval) {
    self.transitionState.mode = "expand"

    // adjust static classname when Expanding?
    if(self.sc.expanding != undefined) {
      self.se.className = self.sc.expanding
    }

    // adjust static classname when Expanding?
    if(self.dc.expanding != undefined) {
      self.de.className = self.dc.expanding
    }

    // expand, using cDuration and cInterval params as override values
    if(cDuration == undefined) cDuration = ($.expansion.cycle.duration == undefined) ? 0 : $.expansion.cycle.duration
    if(cInterval == undefined) cInterval = ($.expansion.cycle.interval == undefined) ? 0 : $.expansion.cycle.interval
    if(cDuration == 0) cInterval = 0 // if no duration, ignore interval setting

    switch($.expansion.direction) {
      case "up":
      case "down":
        linearTransitionInit(cDuration, cInterval, true, true)
        break
      case "left":
      case "right":
        expandInit(cDuration, cInterval, false, true)
        break
    }
  }

  this.contract = function(cDuration,cInterval) {
    self.transitionState.mode = "contract"

    // adjust static classname when contracting?
    if($.classNames.static_Contracting != undefined) {
      self.se.className = $.classNames.static_Contracting
    }

    // adjust static classname when contracting?
    if($.classNames.dynamic_Contracting != undefined) {
      self.de.className = $.classNames.dynamic_Contracting
    }

    // expand, using cDuration and cInterval params as override values
    if(cDuration == undefined) cDuration = ($.expansion.cycle.duration == undefined) ? 0 : $.expansion.cycle.duration
    if(cInterval == undefined) cInterval = ($.expansion.cycle.interval == undefined) ? 0 : $.expansion.cycle.interval
    if(cDuration == 0) cInterval = 0 // if no duration, ignore interval setting

    switch($.expansion.direction) {
      case "up":
      case "down":
        linearTransitionInit(cDuration, cInterval, true, false)
        break
      case "left":
      case "right":
        expandInit(cDuration, cInterval, false, false)
        break
    }
  }

  function linearTransitionInit(cDuration, cInterval, isVertical, isExpanding) {
    if((cDuration != 0) && (cInterval == 0)) {
      alert("ExpansionBar Alert: Interval cannot be greater than zero when a duration is defined.")
      return
    }

    self.transitionState.duration = cDuration                // duration (is milliseconds) for FULL transition
    self.transitionState.interval = cInterval                // time interval between moving cycles (in milliseconds)
    self.transitionState.isExpanding = isExpanding           // true = expanding, false = contracting
    self.transitionState.isVertical = isVertical             // true = vertical, false = horizontal

    if(isVertical && isExpanding) { // vert. exp.
      if(cDuration != 0) {
        self.transitionState.stepDistance = (($.expansion.dimensionMax - $.expansion.dimensionMin) / (cDuration/cInterval))
      } else {
        self.transitionState.stepDistance = $.expansion.dimensionMax - $.expansion.dimensionMin
      }
      setTimeout(linearExpansion, cInterval)
    } else if(isVertical && !isExpanding) { // vert. ctrt.
      if(cDuration != 0) {
        self.transitionState.stepDistance = (($.expansion.dimensionMax - $.expansion.dimensionMin) / (cDuration/cInterval))
      } else {
        self.transitionState.stepDistance = $.expansion.dimensionMax - $.expansion.dimensionMin
      }
      setTimeout(linearContraction, cInterval)
    } else if(!isVertical && isExpanding) { // horiz. exp.

    } else if(!isVertical && !isExpanding) { // horiz. ctrct.

    }
  }

  function linearExpansion() {
    // kick-out if transitionAlert has a "stopExpansion" value
    if(self.transitionState.mode != "expand") {
      return
    }

    if(self.transitionState.isVertical) {   // vertical expansion
      var eleH = undefined

      if(self.de.style.height != undefined) {
        // determine if expansion is at full extension
        if(parseInt(self.de.style.height) >= $.expansion.dimensionMax) {
          self.de.style.height = $.expansion.dimensionMax
          self.transitionState.mode = undefined

          // adjust static classname when Expanded?
          if(self.sc.expanded != undefined) {
            self.se.className = self.sc.expanded
          }

          // adjust dynamic classname when Expanded?
          if(self.dc.expanded != undefined) {
            self.de.className = self.dc.expanded
          }

          return
        } else {
          self.de.style.height = parseInt(self.de.style.height) + self.transitionState.stepDistance + "px"
          setTimeout(linearExpansion, self.transitionState.interval)
        }
      } else {
        self.de.style.height = self.transitionState.stepDistance + "px"
        self.transitionState.mode = undefined
      }
    } else {
      // horizontal expansion
    }
  }

  function linearContraction() {
    // kick-out if transitionAlert has a "stopExpansion" value
    if(self.transitionState.mode != "contract") {
      return
    }

    if(self.transitionState.isVertical) {   // vertical expansion
      var eleH = undefined

      if(self.de.style.height != undefined) {
        // determine if contraction is completed
        if(parseInt(self.de.style.height) <= $.expansion.dimensionMin) {
          self.de.style.height = $.expansion.dimensionMin
          self.transitionState.mode = undefined

          // adjust static classname when Contracted?
          if(self.sc.contracted != undefined) {
            self.se.className = self.sc.contracted
          }

          // adjust dynamic classname when Contracted?
          if(self.dc.contracted != undefined) {
            self.de.className = self.dc.contracted
          }

          return
        } else {
          self.de.style.height = parseInt(self.de.style.height) - self.transitionState.stepDistance + "px"
          setTimeout(linearContraction, self.transitionState.interval)
        }
      } else {
        self.de.style.height = self.transitionState.stepDistance + "px"
        self.transitionState.mode = undefined
      }
    } else {
      // horizontal expansion
    }
  }

  this.disable = function() {
    setState(self.ctrlElement, false, self.eventHandler)
  }

  this.enable = function() {
    setState(self.ctrlElement, true, self.eventHandler)
  }

  function setState(ctrl, enabled, handler) {
    if(enabled) {
      if($.triggers.expandOnClick) {
        ctrl.addEventListener("click", handler, false)
      }
      if($.triggers.expandOnHot) {
        ctrl.addEventListener("mouseover", handler, false)
      }
      if($.triggers.retractWhenCold) {
        ctrl.addEventListener("mouseout", handler, false)
      }
    } else {
      ctrl.removeEventListener("mouseover", handler, false)
      ctrl.removeEventListener("mouseout", handler, false)
      ctrl.removeEventListener("click", handler, false)
    }
  }

  this.pipelineEventProcessor = function (pipeName, event , controlId, srcControl, data) {
    console.log(event)
    switch (event) {
      case "EB_Expand":
        self.expand()
        break
      case "EB_Contract":
        self.contract()
        break
      default:
        /* do nothing */
    }

  }

  // TO-DO: normalize this function into the LogicRail lib ( LR.FireEvent(...) )
  function fireEvent(e) {
    self.pipeline.send(e, undefined)
  }

  this.e_defaultHandler = function (event) {
    var pipeEvent = undefined
    var e = event.type
    var suffix = undefined
    switch(e) {
      case "mouseover":
        fireEvent("EB_MouseOver")
        self.expand()
        break;
      case "mousedown":
        fireEvent("EB_Click")
        break;
      case "mouseout":
        fireEvent("EB_MouseOut")
        self.contract()
        break;
    }
  }

  this.load = function() {
    self.pipeline = new LR.sys.PipelineInterface(self, self.pipelineEventProcessor)
    self.eventHandler = ($.eventHandler) ? $.eventHandler : self.e_defaultHandler
    $.control.container = LR.util.resolveEle($.control.container)

    // construct/integrate main control (element)
    var EB = undefined
    var eb = document.createElement('div')
    eb.id = self.controlId
    if($.control.tabIndex != undefined) eb.tabIndex = $.control.tabIndex
    if(!$.control.container) {
      alert("Invalid (or missing) container setting for control: " + self.controlId)
      return
    }
    self.ctrlElement = EB = $.control.container.appendChild(eb)
    
    // TODO: normalize this entire block with a single reference-pointer to the appropriate dimension (instead of a COMPLETE case block for each combination)
    switch($.expansion.direction) {
      case "up":
        if(self.de != undefined) EB.appendChild(self.de)
        if(self.se != undefined) EB.appendChild(self.se)

        if(($.control.showMode == "contracted") || ($.control.showMode == "expand")) {
          // minimize the Dynamic element
          self.de.style.height = $.expansion.dimensionMin + $.expansion.dimensionScale
          if(self.sc.contracted != undefined) {
            self.se.className = self.sc.contracted
          }
          if(self.dc.contracted != undefined) {
            self.de.className = self.dc.contracted
          }
        } else {
          // maximize Dynamic element
          self.de.style.height = $.expansion.dimensionMax + $.expansion.dimensionScale
          if(self.sc.expanded != undefined) {
            self.de.className = self.sc.expanded
          }
          if(self.dc.expanded != undefined) {
            self.de.className = self.dc.expanded
          }
        }
        break
      case "down":
        if(self.se != undefined) setElementParent(EB, self.se)
        if(self.de != undefined) setElementParent(EB, self.de)

        if(($.control.showMode == "contracted") || ($.control.showMode == "expand")) {
          // minimize the Dynamic element
          self.de.style.height = $.expansion.dimensionMin + $.expansion.dimensionScale
          if(self.sc.contracted != undefined) {
            self.se.className = self.sc.contracted
          }
          if(self.dc.contracted != undefined) {
            self.de.className = self.dc.contracted
          }
        } else {
          // maximize Dynamic element
          self.de.style.height = $.expansion.dimensionMax + $.expansion.dimensionScale
        }
        break
      case "right":
        if(self.se != undefined) setElementParent(EB, self.se)
        if(self.de != undefined) setElementParent(EB, self.de)

        if(($.control.showMode == "contracted") || ($.control.showMode == "expand")) {
          // minimize the Dynamic element
          self.de.style.width = $.expansion.dimensionMin + $.expansion.dimensionScale
          if(self.sc.contracted != undefined) {
            self.se.className = self.sc.contracted
          }
          if(self.dc.contracted != undefined) {
            self.de.className = self.dc.contracted
          }
        } else {
          // maximize Dynamic element
          self.de.style.width = $.expansion.dimensionMax + $.expansion.dimensionScale
          if(self.sc.expanded != undefined) {
            self.de.className = self.sc.expanded
          }
          if(self.dc.expanded != undefined) {
            self.de.className = self.dc.expanded
          }
        }
        break

      case "left":
        if(self.de != undefined) setElementParent(EB, self.de)
        if(self.se != undefined) setElementParent(EB, self.se)

        if(($.control.showMode == "contracted") || ($.control.showMode == "expand")) {
          // minimize the Dynamic element
          self.de.style.width = $.expansion.dimensionMin + $.expansion.dimensionScale
          if(self.sc.contracted != undefined) {
            self.se.className = self.sc.contracted
          }
          if(self.dc.contracted != undefined) {
            self.de.className = self.dc.contracted
          }
        } else {
          // maximize Dynamic element
          self.de.style.width = $.expansion.dimensionMax + $.expansion.dimensionScale
          if(self.sc.expanded != undefined) {
            self.de.className = self.sc.expanded
          }
          if(self.dc.expanded != undefined) {
            self.de.className = self.dc.expanded
          }
        }
        break
    }

    // Expanded element is currently expanded or retracted - determined if it needs to be transitioned
    if ($.control.showMode == "expand") {
      self.expand()
    } else if($.showMode == "contract") {
      self.contract()
    }

    // TODO:
    if($.control.enabled) {
      self.enable()
    } else {
      self.disable()
    }
  self.pipeline.send("EB_Created", undefined)
  }
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                Cycler

Description: Used to cycle images or HTML content through a "viewer." It has three components: the frame, screen and marker.
            Since the aesthetic needs will we much too varied for a "one-size" deal, the control will leverage UI
            layouts as defined by elements established specifically for those two components.
Output Events: Vp_Advance
Input/Pipeline Events: Vp_Next, Vp_Previous, Vp_First, Vp_Last, Vp_Pause, Vp_Play, Vp_Stop

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

Wonka.v0_0307.Defaults.Cycler = {
  /*
  classNames: {                                             // used to set style classes on the main control elements
    control: undefined,
    frame: undefined,
    screen: undefined,
    marker: undefined
  },
  */
  control: {
    container: undefined,
    cycleType: "loop",                                        // {"loop", "reverse", "stop", "end"} end = dead stop (no additional navigation)
    content: {                                               // references to UI elements used for the two control components
      frame: undefined,
      screen: undefined,
      controller: undefined
    },
    enabled: true,                                            // TODO
    initialDelay: undefined,                                  // an extra delay. Useful to let uses "look over" a page before it start to change on them...
    mode: "div",                                              // {"inline", [element type]} inline = attached, otherwise construct new element
    tabIndex: undefined,
    visible: true
  },
  slides: {
    transition: "RTL",                                      // {"RTL", "LTR", "TTB", "BTT"}  TODO: HTML element transitions/fades
    auto: [
    /*  {
          label: undefined,                                 // label is the rollover-text
          target: undefined,                                // either the src (for an type=IMG) or an element id (for type=ID)
          type: "img",                                      // type: {"img", "id"}
          timer: undefined,                                 // number of milliseconds to display this page. (undefined = manual/event-drive behavior)
          transitionTime: undefined                         // number of milliseconds to transition AWAY from this page. (undefined = instantaneous)
        }
    */
    ]                                                       // (image files) or (element IDs)
  },
  events: {
    control: {
      pauseOnHot: false                                       // stop slideshow when hot (mouseover)
    },
    dom: {
      mouseover: undefined,                                   //    TRUE = monitor (internally)
      mouseout: undefined,                                    //    undefined = ignore
      click: undefined,                                       //    delegate = pass event to delegated method for processing
      mousedown: undefined,                                   //    custom event = fires an custom event as defined by "EVENT_FOO"
      mouseup: undefined
    },
    pipes: {                                             // listing of pipe names
      send: [],                                               // presence if "default" control will publish on a pipe-name matching the controlID
      receive: []
    },
    eventHandler: undefined,                                  // custom event handler method (used to process click, mouseover, blur, etc...)
  }
}


Wonka.v0_0307.Cycler = function(controlId, instSettings, templateSettings) {
  var defaultSettings = Wonka.v0_0307.Defaults.Cycler
  this.objectClass = "Cycler"
  this.settings = LR.util.stackSettings(instSettings, templateSettings, defaultSettings)

  this.controlId = controlId
  this.ctrlElements = undefined                  // the top-level HTML element of this control
  this.eventHandler = undefined                  // placeholder
  this.pipeline = undefined
  this.cachedControlParent = undefined            // used to "put back" the control frame (element)
  this.cachedPageParent = undefined               // used to record the a page-element (so it can be returned to the correct place)
  this.screenElement = undefined
  this.controllerElement = undefined
  this.idxPage = undefined                        // identifies the page currently shown on the "screen"
  this.curPage = undefined                        // reference to Page Definition (js object)
  this.curScreenPage = undefined                 // ref to HTML element currently rendered in the Screen
  this.nxtScreenPage = undefined                 // ref to NEXT HTML element rendered in the Screen
  this.prvScreenPage = undefined                 // ref to Previous HTML element rendered in the Screen

  var self = this
  var $ = self.settings

  function nextPage() {
    self.idxPage ++

    // test to make sure not past end of pages...
    if(self.idxPage >= $.slides.auto.length) {
      // mode types: "loop", "reverse", "stop", "end"
      if($.control.cycleType == "loop") {
        self.idxPage = 0
      } else if(($.control.cycleType == "stop") || ($.control.cycleType == "end")) {
        // no more auto-activity...
        return
      }
    }

    // return current page back to its original storage location
    self.cachedPageParent.appendChild(self.curScreenPage)

    var p = self.curPage = $.slides.auto[self.idxPage]

    if(p.type == "img") {
      // load image
    } else if(p.type == "id") {
      // realign DOM element
      var e = document.getElementById(p.target)
      self.cachedPageParent = e.parentElement
      self.curScreenPage = self.ctrlElement.appendChild(e)
      setTimeout(nextPage, p.display)
    } else {
      alert("Unknown Page.type defined in Viewport {control.id} settings...")
    }
  }

  this.pipelineEventProcessor = function (pipeName, event , controlId, srcControl, data) {
    console.log(event)
    switch (event) {
    }
  }

  function fireEvent(e) {
    self.pipeline.send(e, undefined)
  }

// TODO: re-use the same EVENT processing (as ExButton)

  this.show = function() {
    if($.mode == "inline") {
      // inline is used when the HTML element is/was already defined within the UI layout and therefore a "new" UI component
      // does not need to be created.
// TODO: inline instantiation
    } else {
      // create a new Frame UI element (as per mode definition)
      var vp = document.createElement($.mode)
      vp.id = self.controlId
      if($.control.tabIndex) vp.tabIndex = $.control.tabIndex

      // cache current parent (in case it needs to be returned later)
      $.control._hOriginalParent = $.control.content.screen.parentElement
      // vp.appendChild($.control.content.frame)

      self.ctrlElement = $.control.container.appendChild(vp)
      // self.screenElement = $.control.content.screen
      // self.controllerElement = $.control.content.controller
    }

    // are auto-pages defined?
    if($.slides.auto.length != 0) {
      self.idxPage = 0
      var p = self.curPage = $.slides.auto[0]
      if(p.type == "img") {
        // load image
      } else if(p.type == "id") {
        // realign DOM element
        var e = document.getElementById(p.target)
        self.cachedPageParent = e.parentElement
        self.curScreenPage = self.ctrlElement.appendChild(e)

        // element is now on screen...start timer...
        var initDelay = p.display
        // is an initial delay used in this control?
        if($.control.initialDelay != undefined) initDelay += $.control.initialDelay
        setTimeout(nextPage, initDelay)
      } else {
        alert("Unknown Page.type defined in Viewport {control.id} settings...")
      }
    }
  }

  this.load = function() {
    self.pipeline = new LR.sys.PipelineInterface(self, self.pipelineEventProcessor)
    self.eventHandler = ($.eventHandler) ? $.eventHandler : self.e_defaultHandler
    $.control.container = LR.util.resolveEle($.control.container)

// TODO: test visibility...

  /*
    if($.enabled) {
      self.enable()
    } else {
      self.disable()
    }
  */

    self.show()
    self.pipeline.send("EB_Created", undefined)
  }
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                Fader

Description: Fader

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

Wonka.v0_0307.Defaults.Fader = {
  control: {
    content:  undefined,
  },
  events: {
    pipes: {                                             // listing of pipe names
      send: [],                                               // presence if "default" control will publish on a pipe-name matching the controlID
      receive: []
    }
  },
  fadeIn: {
    use: false,
    duration: undefined,
    interval: 25,
    trigger: ["FDR_In"],
    completedEvents: [],
    completedCallback: undefined,
    maxValue: 1,                                          // maximum allowable fade-in value
    allowInterruption: true                               //
  },
  fadeOut: {
    use: false,
    duration: undefined,
    interval: 25,
    trigger: ["FDR_Out"],
    completedEvents: [],
    completedCallback: undefined,
    minValue: 0,                                          // minimum allowable fade-out value
    allowInterruption: true
  },
  pause: {
    allow: false,
    duration: undefined,
    trigger: ["FDR_Pause"],
    completedEvents: [],
    completedCallback: undefined,
  }
}

Wonka.v0_0307.Fader = function(controlId, instSettings, templateSettings) {
  var defaultSettings = Wonka.v0_0307.Defaults.Fader
  this.objectClass = "Fader"
  this.settings = LR.util.stackSettings(instSettings, templateSettings, defaultSettings)

  this.controlId = controlId
  this.eventHandler = undefined                  // placeholder
  this.pipeline = undefined
  this.state = "NEUTRAL"
  this.deltaIn = undefined
  this.deltaOut = undefined

  this.fadeInCallback = undefined
  this.fadeOutCallback = undefined

  var self = this
  var $ = self.settings

  this.fadeOut = function(callback) {
// TODO: check to that current state can be interrupted

    // set STATE variable, as it is used by timing flags
    this.state = "OUT"
    if(!$.control.content.style.opacity) {
      // IF opacity does not have a value, set it to "1" (solid)
      $.control.content.style.opacity = 1
    }

    if(callback) {
      self.fadeOutCallback = callback
    } else if($.fadeOut.callback) {
      self.fadeOutCallback = $.fadeOut.callback
    }

    _fadeOutCycler()
  }

  function _fadeOutCycler() {
    if(self.state != "OUT") return // fade-out has been interrupted

    $.control.content.style.opacity = parseFloat($.control.content.style.opacity) - self.deltaOut
    if(parseFloat($.control.content.style.opacity) > $.fadeOut.minValue) {
      // cycle to next interval
      setTimeout( _fadeOutCycler, $.fadeOut.interval)
    } else {
      $.control.content.style.opacity = $.fadeOut.minValue
      this.state = "NEUTRAL"
// TODO:  test to see if pipeline event needs to be fired
      if(self.fadeOutCallback) {
        self.fadeOutCallback()
        self.fadeOutCallback = undefined
      }
    }
  }

  this.fadeIn = function(callback) {
// TODO: check to that current state can be interrupted
    // set STATE variable, as it is used by timing flags
    this.state = "IN"
    if(!$.control.content.style.opacity) {
      // IF opacity does not have a value, set it to "1" (solid)
      $.control.content.style.opacity = 0
    }

    if(callback) {
      self.fadeInCallback = callback
    } else if($.fadeIn.callback) {
      self.fadeInCallback = $.fadeIn.callback
    }
    _fadeInCycler()
  }

  function _fadeInCycler() {
    if(self.state != "IN") {
      return // fade-out has been interrupted
    }

    if(parseFloat($.control.content.style.opacity) < $.fadeIn.maxValue) {
      $.control.content.style.opacity = parseFloat($.control.content.style.opacity) + self.deltaIn
      // cycle to next interval
      setTimeout( _fadeInCycler, $.fadeIn.interval)
    } else {
      $.control.content.style.opacity = $.fadeIn.maxValue
      this.state = "NEUTRAL"
// TODO:  test to see if pipeline event needs to be fired
      if(self.fadeInCallback) {
        self.fadeInCallback()
        self.fadeInCallback = undefined
      }
    }
  }

  this.pipelineEventProcessor = function (pipeName, event , controlId, srcControl, data) {
    console.log(event)
    switch (event) {
    }
  }

  function fireEvent(e) {
    self.pipeline.send(e, undefined)
  }

  this.load = function() {
    self.pipeline = new LR.sys.PipelineInterface(self, self.pipelineEventProcessor)
    self.eventHandler = ($.eventHandler) ? $.eventHandler : self.e_defaultHandler
    $.control.container = LR.util.resolveEle($.control.container)

    if($.fadeIn.use) {
      if(!$.fadeIn.duration) {
        alert("Fader.fadeIn.duration is invalid...cannot use Fade-In functionality")
        $.fadeIn.use = false
      }
      if(!$.fadeIn.interval) {
        alert("Fader.fadeIn.interval is invalid...cannot use Fade-In functionality")
        $.fadeIn.use = false
      }

      self.deltaIn = 1 / ($.fadeIn.duration / $.fadeIn.interval)
    }

    if($.fadeOut.use) {
      if(!$.fadeOut.duration) {
        alert("Fader.fadeOut.duration is invalid...cannot use Fade-Out functionality")
        $.fadeOut.use = false
      }
      if(!$.fadeOut.interval) {
        alert("Fader.fadeOut.interval is invalid...cannot use Fade-out functionality")
        $.fadeOut.use = false
      }

      self.deltaOut = 1 / ($.fadeOut.duration / $.fadeIn.interval)
    }
  }
}


/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                Viewport

Description: Viewport is a logical object that manages a "physical" viewing space. Somewhat analogous to a television,
             the viewport has a screen component. The content that is displayed is labeled the "Active"
             content. The other "channels" are held in an operational BUT non-visible state. There are a number of
             options available for effectively "changing" the channel, and those options are comprised for the settings
             associated for both the INBOUND content, and the OUTBOUND.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

Wonka.v0_0307.Defaults.Viewport = {
  control: {
    className: undefined,                                   // a state-independent mechanism
    container: undefined,
    enabled: true,
//     initialState: udefined,                              // NOT USED (for LR conformity??)
    tabIndex: undefined,
    type: "div",                                            // Control DOM element type
    visible: true,
    fadeInterval: 0,                                        // number of millisecond-interval used in fade transitions
    fadeDuration: 0,                                        // default transitions are instantaneous
    activeChannelId: undefined,                             // channels are ID'd; this is the ID for the Active channel
    transition: "default",                                   // {"default", callback} DEFAULT = fade
    storageLocation: "WonkaWidgets"
  },
  events: {
    dom: {                                                  // ADD any/all events here (typically: mouseover, mouseout, click)
// TODO: incorporate _TEMPATE_ functionality into events.dom
      _TEMPLATE_: {
        delegate: undefined,
        navAttribute: undefined,
        navLocation: undefined,
        navTarget: undefined,
        pipelineEvents: [],
        switchToChannel: undefined
      }
    },
    pipes: {
      send: [],
      receive: []
    },
    processor: undefined
  },
  channels: [
    {
      id: undefined,
      content: {
// TODO: add a method to LR for retreiving URL data (already exitst) AND extending the DOM with its content...
// NOTE: it needs to accommodate both JS logic as well as HTML mark-up...maybe hide in iFrame and then "scrape" content?
        element: undefined,                                 // {UNDEFINED, element.ID, or element reference}  String -> element.id
        literal: undefined                                  // used to *programmatically* construct the content element
      },
      classNames: {
        active: undefined,                                  // [undefined] = ignore, "" = erase
        inactive: undefined
      },
      pipelineEvents: {
        active: [],                                         // OUTPUT events sent when this channel becomes ACTIVE
        inactive: [],                                       // OUTPUT events sent when this channel becomes INACTIVE
        loaded: [],                                           // OUTPUT events sent when this channel is LOADED
// TODO: (triggers)
        triggers: [],                                       // INPUT event(s) that trigger this channel to become ACTIVE
      }
    }
  ]
}
Wonka.v0_0307.Viewport = function(controlId, instSettings, templateSettings) {
  var defaultSettings = Wonka.v0_0307.Defaults.Viewport
  this.objectClass = "Viewport"
  this.settings = LR.util.stackSettings(instSettings, templateSettings, defaultSettings)

  this.controlId = controlId
  this.eventHandler = undefined                  // placeholder
  this.pipeline = undefined
  this.Control = undefined
  this.Channels = {}
  this.TriggerMap = {}                            // a construct that is used to map channel Triggers to the channels

  var self = this
  var $ = self.settings

  // show a given channel as determined by its ID
  this.showChannel = function(channelId) {
    var newChannel = self.Channels[channelId]

// TODO: return "old" channel to its proper location

    // move new channel into Viewport

    self.Control.appendChild(newChannel._hContent)
    $.control.activeChannelId = newChannel.id
    $.control._hActiveChannel = newChannel
  }

  this.pipelineEventProcessor = function (pipeName, event , controlId, srcControl, data) {
    // trigger associated with this pipe event??
    if(typeof self.TriggerMap[event] == "undefined") return

    // return existing channel to its original place....
    $.control._hActiveChannel._hOriginalParent.appendChild($.control._hActiveChannel._hContent)
// TODO: fire any "Inactive" event(s)

    // render new Channel
    self.Control.appendChild(self.TriggerMap[event]._hContent)
    $.control._hActiveChannel = self.TriggerMap[event]
// TODO: fire any "Active" event(s)
  }

  function fireEvent(e) {
    self.pipeline.send(e, undefined)
  }

  this.load = function() {
    self.pipeline = new LR.sys.PipelineInterface(self, self.pipelineEventProcessor)
    self.eventHandler = ($.eventHandler) ? $.eventHandler : self.e_defaultHandler
    $.control.container = LR.util.resolveEle($.control.container)

    $.control.storageLocation = LR.util.resolveEle($.control.storageLocation)

    var ctrl = document.createElement($.control.type)
    ctrl.id = self.controlId
    if($.control.className) ctrl.className = $.control.className
    if($.control.tabIndex) ctrl.tabIndex = $.control.tabIndex
    $.control.container = LR.util.resolveEle($.control.container)
    self.Control = $.control.container

    for(var idx = 0; idx < $.channels.length; idx++) {
      var chn = $.channels[idx]
      // create a convenience reference
      self.Channels[chn.id] = chn
      // establish content element

      if(chn.content.literal) {
        // insert the literal into the DOM under the WonkaTools element
        var temp = document.createElement("div")
        temp.innerHTML = chn.content.literal
        chn._hContent = $.control.storageLocation.appendChild(temp.firstChild)
        chn._hOriginalParent = chn._hContent.parentElement
      } else if(chn.content.element) {
        chn._hContent = LR.util.resolveEle(chn.content.element)
        if(!chn._hContent) {
          alert("Channel content named, but element does not exist: " + chn.content.element)
          return
        }
        chn._hOriginalParent = chn._hContent.parentElement
      } else {
        alert("Channel has no content defined: " + chn.id)
        return
      }

      if(chn.classNames.inactive) chn.className = chn.classNames.inactive

      if((chn.pipelineEvents.triggers) && (chn.pipelineEvents.triggers.length != 0)) {
        for(var x = 0; x < chn.pipelineEvents.triggers.length; x++) {
          // record channel pointers for each trigger. NOTE: since only channel can be active at a time, triggers must
          // be unique...if they are duplicated, the most recent setting value is used
          self.TriggerMap[chn.pipelineEvents.triggers[x]] = chn
        }
      }
    }

    if(($.control.visible) && ($.control.activeChannelId)) {
      self.showChannel($.control.activeChannelId)
    }
  }
}











