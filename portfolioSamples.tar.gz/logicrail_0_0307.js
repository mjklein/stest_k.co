/********************************************************************************************************************
**
**    LogicRail(tm) Software Library
**    Version: 0.03.1
**
**    Copyright 2013-2014  Informive Corporation
**    ALL RIGHTS RESERVED
**    __________________________________________
**
**    NOTICE: This software library is the exclusive property of Informive Corporation and may not be copied,
**    modified, redistributed or otherwise reproduced in any form or manner without the express written consent of
**    Informive Corporation.
**
**    "LogicRail" is a protected trademark of Informive Corporation.
**
**    For questions or issues pertaining to this code library, contact us via email at Legal@Informive.com
**
********************************************************************************************************************/


// empty LogicRail object (hanger); mapped here for easier understanding
var LR = {
  version: 0.5,
  memSpace: {},               // used as a collective name-space for sharable/persistent control variables
  registry: {
    controls: {
      autoCreateList: {},     // filled via regControl(...)
      autoCreateLists: [],    // filled via regControlList(...)
      ids: {},
      map: {
        idToDefinition: {},
        idToInstance: {}
      }
    },
    libraries: {}         // each Named library (as Array) will include and object: { X.version, X.reference }
  },
  sys: {},
  util: {}
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                      Object management Functions

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */


// create a Control instance based upon a ControlDef object/settings
LR.sys.createControl = function(ctrlDef) {
  if(typeof ctrlDef == "undefined") {
    alert("LogicRail cannot create an undefined object. Verify regControl ids...")
    return
  }

  var ctrl = undefined
  // determine if the object definition is using a proprietary objectConstructor method...
  if(typeof ctrlDef.objectConstructor == 'function') {
    // this control is being created by an object constructor method
    ctrl = ctrlDef.objectConstructor.call()
  } else {
    var id = ctrlDef.controlId
    var maxVer = ctrlDef.assembly.maxLibVersion
    var minVer = ctrlDef.assembly.minLibVersion
    var lib = LR.getLibrary(ctrlDef.assembly.library, minVer, maxVer)
    var instSettings = ctrlDef.getInstanceSettings()
    var templSettings = ctrlDef.getTemplateSettings()
    var objExtensions = ctrlDef.objectExtensions
// TODO: verify Element sources (IF LogicRail_mode = "active")
    ctrl = new lib.reference[ctrlDef.assembly.controlProto](id, instSettings, templSettings, objExtensions)
  }
  if(ctrl == undefined) return
  ctrl.load()
  return ctrl
}

/*
  The "Registry" is actually an object, as opposed to an array. indexing is done by converting index-values to
  alphabetical format and then letting the JS engine do the sorting automatically.
  This is a Direct registration method for objects. typically called at the end of a given script file to register the
  objects that need to be "auto" created
*/
LR.regControl = function(index, controlRef) {
  // test to see if exact index value already exists. Two objects registering using the same Index value will be processed FIFO
  if(typeof LR.registry.controls.autoCreateList["idx_" + index] != "undefined") {
    // collision of index values...need to synthesize
    alert("Duplicate Object Index-values...")
    return
  }
  LR.registry.controls.autoCreateList["idx_" + index] = controlRef
}

/*
  This registers a control list. The sequence of controls will be preserved WITHIN the list, however multiple lists CAN
  be registered. Also, controls registered in this manner are initialized AFTER any/all controls registered with using
  an Indexer value [ie, via regControl()]
*/
LR.regControlList = function(ctrlArray) {
  if((ctrlArray == undefined) || (ctrlArray.length ==0)) return
  // add control-list into registry
  LR.registry.controls.autoCreateLists.push(ctrlArray)
}

/*
  Object Libraries are registered here by their Name and a versioned-namespace reference
  NOTE:
    1) ALL LogicRail compliant libraries MUST include a "[versionRef].version" attribute; that value is indexed alphabetically
    2) the version is not extracted from the reference so as to allow maximum namespace flexibility for the developer
*/
LR.regLibrary = function(name, versionRef) {
  // determine if the library-id object already exists
  if(typeof LR.registry.libraries[name] == "undefined") {
    // new library is being registered
    LR.registry.libraries[name] = new Array()
  }
  // create version object
  var libEntry = {
        reference: versionRef,
        version: versionRef.version
      }
  LR.registry.libraries[name].push(libEntry)
}

/*
  Retrieves a registered Object Library based upon its name, and version criteria
*/
LR.getLibrary = function(name, minVer, maxVer) {
  var libStack = LR.registry.libraries[name]
  var flag = true
  var rv = undefined

  if((typeof libStack == "undefined") || (libStack.length == 0)) {
    alert("Requested object library '" + name + "' is not valid")
    return
  }

  // iterate through ALL version in a library stack; the allows the most up-to-date version to be found last IF the developer
  // as chosen to load them in a sequential manner
  for(var x = 0; x < libStack.length; x ++) {
    var lib = libStack[x]
    if((minVer != undefined) && (minVer < lib.version)) flag = false
    if((maxVer != undefined) && (lib.version > maxVer)) flag = false
    if(flag) rv = lib
    flag = true
  }
  return rv
}


/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                      PipelineInterface

Description: interface into the LogicRail EventPipe system

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

/*
  NOTE: The following settings are optional:
    1) settings (control.settings)
    2) controlId (control.controlId)
    3) send (TODO)  control.settings.eventPipes.send
    4) receive (TODO) control.settings.eventPipes.receive
*/

LR.sys.PipelineInterface = function(control, eventCallback, settings, controlId, sendPipelines, receivePipelines) {
  this._pipelineSendInterfaces = []   // an object-interface for each of the output pipes (done via registration)
  this.control = control
  this.controlId = undefined
  this.receivePipelines = undefined
  this.sendEnabled = true
  this.sendPipelines = undefined
  this.settings = undefined
  this.eventCallback = eventCallback
  var self = this

  if(controlId != undefined) {
    self.controlId = controlId
  } else {
    self.controlId = control.controlId
  }

  if(settings != undefined) {
    self.settings = settings
  } else {
    self.settings = control.settings
  }

  // **** SEND pipeline configuration
  if(typeof sendPipelines == "undefined") {
    // SendPipelines have been declared by parameter
    self.sendPipelines = self.settings.events.pipes.send
  }

  // if(typeof self.sendPipelines != "array") {
  if((self.sendPipelines == undefined) || (self.sendPipelines.length == undefined)) {
    self.sendEnabled = false
  } else if(self.sendPipelines.length == 0) {
    // array is empty...therefore use DEFAULT setting (controlID)
    self._pipelineSendInterfaces.push(LR.sys.PipelineManager.register(self.controlId))
  } else if(typeof self.sendPipelines == "string") {
    var pipeName = self.sendPipelines
    if(pipeName.toUpperCase() == "DEFAULT") {
      // default pipe name = controlId
      self._pipelineSendInterfaces.push(LR.sys.PipelineManager.register(self.controlId))
    } else {
      self._pipelineSendInterfaces.push(LR.sys.PipelineManager.register(pipeName))
    }
  } else {
    // there are pipes named...iterate and add
    for(var i = 0; i < self.sendPipelines.length; i++) {
      var pipeName = self.sendPipelines[i]
      if(pipeName.toUpperCase() == "DEFAULT") {
        // default pipe name = controlId
        self._pipelineSendInterfaces.push(LR.sys.PipelineManager.register(self.controlId))
      } else {
        self._pipelineSendInterfaces.push(LR.sys.PipelineManager.register(pipeName))
      }
    }
  }

  // **** RECEIVE pipeline configuration
  if(receivePipelines != undefined) {
    self.receivePipelines = receivePipelines
  } else if(self.settings.events.pipes.receive != undefined) {
    self.receivePipelines = self.settings.events.pipes.receive
  } else {
    self.receivePipelines = undefined
  }

  // configure the input pipes
  for(var i = 0; i < self.receivePipelines.length; i++) {
    LR.sys.PipelineManager.attach(self.receivePipelines[i], eventCallback)
  }

  // Send event to all of the output pipes
  this.send = function(event, data) {
    if(self.sendEnabled) {
      for(i = 0; i < self._pipelineSendInterfaces.length; i ++) {
        self._pipelineSendInterfaces[i].send(event, self.controlId, self.control, data)
      }
    }
  }

  this._destroy = function() {
    // detach the event event pipeline
    for(var i = 0; i < self.receivePipelines.length; i++) {
      LR.sys.PipelineManager.detach(self.receivePipelines[i], self.eventCallback)
    }
    this._pipelineSendInterfaces = undefined
    this.sendEnabled = undefined                // by default
    this.settings = undefined
    this.self = undefined
    this.$ = undefined
  }
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                       PipelineManager

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

LR.sys.PipelineManager = {
  queueEventIds: {
    // This are ID constants for Q-Level events (not to be confused with UI-Level events)
    // There events are sent to Qmonitor() callbacks, whereas UI (and websocket) Events are sent to eventProc() callback methods
    NewEventQueue: 1
  },
  qMap: {},    // a Map of Q-Info's, keyed to the pipeName
  qInfo: function (name, monitorCallback) {
    // internalized structure (object) that holds the details associated with any particular queue.
    this.name = name
    this.status = 1 // default is initializing (1) when starting
    this.listeners = new Array()  // a List (array) of listener callbacks. when count == 0, this Q will go OnHold
    this.callback = monitorCallback // receives various life-cycle events from the queue itself (including errors)
  },
  attach: function (pipeName, callback) {
    // attaches a listener to the named Queue. if the Q does not exist, it is created
    if (this.qMap[pipeName]) {
      this.qMap[pipeName].listeners.push(callback)
    } else {
      this.register(pipeName, undefined)
      this.qMap[pipeName].listeners.push(callback)
    }
  },
  detach: function (pipeName, callback) {
    // detaches a listener from a even pipeline
    if(this.qMap[pipeName]) {
      // pipeline exists...remove the listener callback
      for(var i = 0; i < this.qMap[pipeName].listeners.length; i++) {
        if(this.qMap[pipeName].listeners[i] == callback) {
          // remove the current index (and down-shift any remaining elements)
          for(var seg = i + 1; seg < this.qMap[pipeName].listeners.length; seg ++) {
            this.qMap[pipeName].listeners[seg - 1] = this.qMap[pipeName].listeners[seg]
          }
          // all elements AFTER "i" have been left-shifted; remove the last element (since the array is one less at this point)
          this.qMap[pipeName].listeners.pop()
        }
      }
    }
  },
  send: function (pipeName, event , controlId, srcControl, data) {
    // the publication method of Event Queues
    var q = this.qMap[pipeName]
    var listeners = q.listeners
    for (var i = 0; i < listeners.length; i++) {
      // bombs away...
      listeners[i](pipeName, event, controlId, srcControl, data)
    }
  },
  register: function (pipeName, monitorCallback) {
    // create a new Queue if one does not current exist with this pipeName
    if (this.qMap[pipeName]) {
      // an Event queue of that name already exists, return interface to existing...
      return {
        pipeName: pipeName,
        send: function(event , controlId, srcControl, data) { LR.sys.PipelineManager.send(this.pipeName, event , controlId, srcControl, data) }
      }
    }
    var qi = new this.qInfo(pipeName, monitorCallback)
    // now create a Q-Info structure with necessary settings information; add qInfo to hash
    this.qMap[pipeName] = qi
    // send startup notifier to the q monitoring callback (if defined - most Queues will be "unmonitored")
    if (monitorCallback) {
      monitorCallback(1, pipeName)
    }
    // that's it... return an interface to this new Q
    return {
      pipeName: pipeName,
      send: function(event , controlId, srcControl, data) { LR.sys.PipelineManager.send(this.pipeName, event , controlId, srcControl, data) }
    }
  }
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                      Web Sockets Bridge

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */


// NOTE: WebSock support is integrated as an Event Queue. This provides a bridge mechanism between server logic and
// client-side UI/Control events. For example, the server could be sent a message when the value of a listBox changes.
LR.sys.webSocket = function() {
  // activate is sectioned off so that Q's can be created and Listeners can be added before the Atom connection is established
  this.init = function() {
    /*    NOTE: this is an Atmosphere/Websocket interface
    request.url = halonMessagingServiceRoute,
    request.contentType = "application/json"
    request.transport = "websocket"
    request.fallbackTransport = "long-polling"
    request.logLevel = "debug"

    request.onOpen = function(response) {
      transport = response.transport
    }
    request.onReconnect = function(rq, rs) {}
    request.onMessage = function(response) {
      var message = response.responseBody
      var hmsMessage = JSON.parse(message)
      hmsMessage.target="client"
      self.publish(hmsMessage)
    }
    request.onClose = function(rs) {}
    request.onError = function(rs) {}
    // establish a WS connection using the attributes/settings defined by "request"
    self.wsConnection = this.socket.subscribe(request)
    */
  }
}

/*******************************************************************************************************************
/*******************************************************************************************************************
/*******************************************************************************************************************
**
**                                  LogicRail - Library Utilities
**
/*******************************************************************************************************************/
/*******************************************************************************************************************/
/*******************************************************************************************************************/

/*
  This function is used to "layer" settings in a prioritized fashion. Following the LogicRail structure, Controls
  have three layers of settings, in order of highest priority: Instance, Template, Default. This provides developers
  with a huge level of flexibility and deployment efficiency. While this is the suggested design pattern (and the
  one that will be required for the LogicBase IDE, it is at the developers discretion especially in cases where there
  is no intent to commercialize the Control(s).

  This process uses an outside-in flow. Instead of overriding via an inheritance chain, start with the most
  specific layer (Instance), then fills in any "undefined" settings with Template, and likewise for Default settings.
*/
LR.util.stackSettings = function(i, t, d) {
  // NOTE: this method is prone to circular reference errors, especially when DOM elements are involved.
  // var instSettings = JSON.parse(JSON.stringify(i))

  var instSettings = new Object()

  for(var a in i) {
    if(i.hasOwnProperty(a)) {
      instSettings[a] = i[a]
    }
  }

  // Layer 2 --> Template
  if(t != undefined) {
    fillSettings(instSettings, t)
  }
  // Layer 3 --> Defaults
  fillSettings(instSettings, d)

  return instSettings

  // finally, set all un-established values to the Default settings...
  function fillSettings(writeProtected, optional) {
    for(var attr in optional) {
      if(typeof optional[attr] == "object") {
        if(writeProtected.hasOwnProperty(attr)) {
          fillSettings(writeProtected[attr], optional[attr])
        } else {
          // ! hasOwnProperty (object) ... reference the whole thing ...
          writeProtected[attr] = optional[attr]
          // writeProtected[attr] = undefined
          // fillSettings(writeProtected[attr], optional[attr])
        }
      } else if(!writeProtected.hasOwnProperty(attr)) {
        writeProtected[attr] = optional[attr]
      }
    }
  }
}

/*
  This function tries to convert a given value into an object (if it is not already one)
  Acceptable val types:
    1) String
    2) Object
    3) Function
*/
LR.util.resolveEle = function(val) {
  // determine the container
  switch(typeof val) {
    case "string":
      // Strings are considered to be and element ID
      return document.getElementById(val)
      break
    case "object":
      return val
      break
    case "function":
      return val.call()
    default:
  }
}

// translate dot-notation into an object reference (eg, foo = bar.baz.asObject())
// NOTE: this is a recursion method, so the "object" argument is optional (for the first call)
LR.util.getQualifiedObject = function(qualifiedName, object) {
  var layers = qualifiedName.split(".")
  if (layers.length != 0) {
    // obj will be undefined for first iteration; requires special handling
    if (object == undefined) {
      object = window[layers[0]]
    } else {
      // object reassignment
      object = object[layers[0]]
    }
    // drop the "first" of the remaining object layers
    var subIdx = qualifiedName.indexOf(".")
    if (subIdx != -1) {
      // "dot" separator found; more layers to go
      qualifiedName = qualifiedName.substring(subIdx +1)
      return HUI.lib.getQualifiedObject(qualifiedName, object)
    } else {
      // nested recursion finished.
      return object
    }
  } else {
    // the original object path was not nested
    return object
  }
}

// calculates position of element irregardless of DOM nesting
LR.util.getDocumentPosition = function(element, docCoordinates) {
  // create a coordinates object is one was not assigned
  if(docCoordinates == undefined) {
    docCoordinates = {
      x: 0,
      y: 0
    }
  }

  // walks up a DOM tree and through IFrame containment to get "screen" coordinates for a given initial target
  if (element.offsetParent) {
    // if the element HAS an offset parent, then it has offsetLeft and offsetRight values that need to be aggregated
    docCoordinates.x += element.offsetLeft
    docCoordinates.y += element.offsetTop
    HUI.lib.getDocumentPosition(element.offsetParent, docCoordinates) // iterate to offsetParent
  }
  return docCoordinates
}

// relative location from nearest Positioned ancestor
LR.util.getPositionedOffset = function(element, coordinates) {
  // create a coordinates object if one was not assigned (first iteration)
  if(coordinates == undefined) {
    coordinates = {
      x: 0,
      y: 0
    }
  }

  if (element.offsetParent) {
    switch(window.getComputedStyle(element).position) {
      case "relative":
      case "absolute":
      case "fixed":
        return coordinates
      default:
        coordinates.x += element.offsetLeft
        coordinates.y += element.offsetTop
        HUI.lib.getPositionedOffset(element.offsetParent, coordinates) // step into offsetParent
    }
  }
  return coordinates
}

// use AJAX to load content off of the server
LR.util.ajaxRequest = function (method, url, async, successCallback, failCallback) {
  var xhr = new XMLHttpRequest();
  xhr.onload = function(e) {
    successCallback(xhr.responseText)
  }
  xhr.onError = function(e) {
    failCallback(e)
  }
  xhr.open(method, url, async);
  xhr.send();
}

// Creates an AJAX FormData object that contains the serialized field values
LR.util.packRdoIntoFormData = function(rdo) {
  var fd = new FormData()
  // iterate through each of the field/values, adding them to the FormData along
  for (var i = 0; i < rdo.fields.length; i++) {
    var field = rdo.fields[i]
    var value = field.value

    // make sure value is not an Object...
    if(typeof value != "string") {
      value = JSON.stringify(value)
    }

    // scrub data (null, NULL, undefined, etc.)
    switch(field.value) {
      case "null": case "NULL": case "Null": case "undefined": case undefined:
        value = ""
        break
      // ADD additional cases here
    }
    fd.append(field.name, value)
  }
  return fd
}

LR.util.addParameterToGet = function(url, parameter, value) {
  // determine if URL already has parameters
  if (url.indexOf("?") == -1) {
    // no existing params
    return url + "?" + parameter + "=" + value
  } else {
    return url + "&" + parameter + "=" + value
  }
}

// TODO: determine which viewport/iFrame the scoped-document is being displayed in (assumes primary for the time being)
LR.util.activateModalViewport = function(background) {
  // do nothing if the overlay is already present - otherwise create one
  // NOTE: this will mostly occur whenever a viewport document (containing an active modal control) is refreshed
  if (top.document.getElementById("PrimaryVpOverlay")) return

  // get the z-Index value of the primary iFrame
  var vp = top.document.getElementById("viewport1")
  var priVpZIndex = vp.style.zIndex

  if(background == undefined) {
    background = "rgba(0, 0, 0, .4)"
  }

  var overlay = top.document.createElement("div")
  overlay.id = "PrimaryVpOverlay"
  overlay.style.position = "absolute"
  overlay.style.top = "0px"
  overlay.style.left = "0px"
  overlay.style.width = "100%"
  overlay.style.height = "100%"
  overlay.style.display = "block"
  overlay.style.background = background
  overlay.style.zIndex = priVpZIndex - 1

  // attach the overlay
  LR.memSpace.primaryVpOverlay = top.document.getElementById("console").appendChild(overlay)
}

LR.util.deactivateModalViewport = function() {
  if(HUI.memSpace.primaryVpOverlay) {
    top.document.getElementById("console").removeChild(HUI.memSpace.primaryVpOverlay)
  }
}

// convenience method for modifying DOM-Element classnames
LR.util.StateManager = {
  add: function(element, state, cacheName) {
    // adds a State setting for an element; optional: caches the previous state value
    var curState = element.getAttribute("data-HUI-state")
    var newState = undefined

    if((curState == undefined) || (curState = "") || (curState == null)) {
      newState = state
    } else {
      newState += " " + state
    }
    if(cacheName != undefined) {
      element.setAttribute(cacheName, curState)
    }
    element.setAttribute("data-HUI-state", newState)
    return newState
  },
  remove: function(element, state, cacheName) {
    // remove a State setting (and cache) from an element
    if(cacheName != undefined) {
      element.removeAttribute(cacheName)
    }
    var curState = element.getAttribute("data-HUI-state")
    if(curState == null) {
      // HUI-Control does not implement 'sate' mechanics !?
      element.setAttribute("data-HUI-state", "")
      return
    } else {
      var newState = curState.replace(state, "")
      element.setAttribute("data-HUI-state", newState.trim())
      return newState
    }
  },
  revertToCachedState: function(element, cacheName) {
    // revert to a cached state
    if(cacheName != undefined) {
      var oldState = element.getAttribute(cacheName)
      element.setAttribute("data-HUI-state", oldState)
    }
    return oldState
  }
}

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                                                 LogicRail Execution

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

// see INIT section for "mode" options
LR.run = function(mode) {
  // ALL indexed controls take precedence over those without indexers
  for(var idx in LR.registry.controls.autoCreateList) {
    var ctrl = LR.registry.controls.autoCreateList[idx]
    LR.sys.createControl(ctrl)
  }

  // control LISTS are parsed and instantiated in FIFO order
  for(var idx = 0; idx < LR.registry.controls.autoCreateLists.length; idx++) {
    var ctrlList = LR.registry.controls.autoCreateLists[idx]
    for(var z = 0; z < ctrlList.length; z++) {
      LR.sys.createControl(ctrlList[z])
    }
  }
}

/*
  Find the LogicRail script and then extract the Run settings.
  There are (4) run modes:
    1) OnLoad - run() triggered by document.onLoad event
    2) OnReady - run() triggered by DOMContentLoaded event
    3) Active - run() start immediately and object-creations use element polling to determine availability
    4) Passive - run() must be called by an external process (THIS IS THE DEFAULT)
*/
var lrScripts = document.getElementsByTagName("script")
for(var i = lrScripts.length; i--;) {
  if(lrScripts[i].getAttribute("data-LR_VER") != undefined) {
    var mode = lrScripts[i].getAttribute("data-LR_MODE")
    if(mode == undefined) mode = "Passive"
    switch(mode) {
      case "Passive":
        // do nothing (run() must be triggered manually by external process)
        alert("P")
        break
      case "Active":
        // load Objects using active-polling (EXPERIMENTAL); (most resource intensive)
        alert("A")
        break
      case "OnReady":
        // run when the DOM is ready (middle of the road speed/ease; legacy support somewhat limited)
        document.addEventListener("DOMContentLoaded", LR.run, false)
        break
      case "OnLoad":
        // run after all page resources have been acquired (slowest automatic setting, but fully adopted)
        window.onload = LR.run
        break
      default:
        alert("Unknown LogicRail 'mode' setting")
        break
    }
  }
}



/*******************************************************************************************************************
/*******************************************************************************************************************
/*******************************************************************************************************************
**
**                                                   LogicRail Object Prototype
**
** Objects do NOT have to extend this extend this particular object, as it for ease-of-use. HOWEVER,
** LogicRail compatible objects MUST provide the necessary interface functions...even if manually coded.
**
/*******************************************************************************************************************/
/*******************************************************************************************************************/
/*******************************************************************************************************************/

LR.sys._baseObject = function() {
  // TODO: tranfer core functionality interface methods
}
