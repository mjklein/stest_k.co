"use strict"

var socketPort = 8088

var WebSocketServer = require('websocket').server
var http = require('http')
var server = http.createServer(function(request, response) {})
var registeredChannels = {}

server.listen(socketPort, function() {})

var wsServer = new WebSocketServer({
	httpServer: server
})

function senderAllowed(conn) {
// TODO: filter broadcaster rights
	return true	
}

wsServer.on('request', function(r){
	var connection = r.accept('echo-protocol', r.origin)
	var hChannel = undefined
	
	// Create event listener
	connection.on('message', function(message) {
		if(message == "") return // exit on empty
		if(message.type === "utf8") {
			var msg = message.utf8Data
			if(!hChannel) {
				// the FIRST connection to identify a channelId?
				if(registeredChannels[msg] == undefined) {
					// this is the channelId owner (broadcaster)
					registeredChannels[msg] = {
						id: msg,
						owner: connection,
						connections: new Array()
					}
					console.log((new Date()) + " New channel being created created: " + msg)
				} else {
					// this is a new connection for and existing channel
					console.log((new Date()) + " New listener being added to channel: " + msg)				
				}
				registeredChannels[msg].connections.push(connection)
				hChannel = registeredChannels[msg]
			} else {
				// this connection is already associated with a channel. since only broadcasters 
				// can send additional messages (beyond the channel association), this is a broadcaster.
				// we also know that the msg does NOT contain a channelID...since it is a broadcaster
				// message
				console.log((new Date()) + " Message (" + msg + ") being broadcast on channel: " + hChannel.id)
				for(var i = 0; i < hChannel.connections.length; i++) {
					var conn = hChannel.connections[i]
					if(conn != undefined) {
						conn.sendUTF(msg)
					}
				}
			}	
		}
	})

	connection.on('close', function(reasonCode, description) {
		// determine if the closing-connection is the owner
		if(hChannel.owner == connection) {
			// channel owner is closing, shut down the channel
			var id = hChannel.id
			for(var i = 0; i < hChannel.connections.length; i++) {
				delete hChannel.connections[i]
			}			
			registeredChannels[id] = undefined
			hChannel = undefined
			console.log((new Date()) + ' Channel distroyed.')			
		} else {
			// connection is associated with a listener
			for(var i = 0; i < hChannel.connections.length; i++) {
				if(hChannel.connections[i] == connection) {
					delete hChannel.connections[i]
					hChannel.connections[i] = undefined
				}
			}
		}
		console.log((new Date()) + ' Connection ' + connection.remoteAddress + ' disconnected.')
	})	
})


