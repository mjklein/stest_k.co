﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using VisualInform.Plugin;  // from the referenced API DLL
using Lib.LinkTable;


/*
 * 
 * Every VisualInform Plugin Library must contain a class called "Manager" that is derived
 * from the API's VisualInform.Plugin.Manager class. This class is the "point or contact" between the
 * library and Visual Inform's Librarian -- which is responsible for the management of plugin objects.
 * 
 * 
 * TO-DO's :
 *  1) Add licensing capabilities into the manager/VI
 *  
 */

namespace Lib
{
    public class Manager : VisualInform.Plugin.Manager
    {
        public Manager()
        {
            // default constructor....probably should be passed a handle to the Librarian, but not now...
        }

        public override String CompanyName_Get()
        {
            return "ThinkDigital, Inc."; 
        }

        public override Boolean Objects_Register(LinkedList<cRegistryTag> tags)
        {
            // create a local var for packages tags
            cRegistryTag tag = new cRegistryTag();

            tag.ClassTypeID = new Guid("{81E5AB04-906E-429d-B9B3-A97C15067D27}");       // VPO_Links
            tag.ClassID = new Guid("{BB897653-4AE5-4b53-9D32-14102C2190B7}");     // Binder.VPO.VPO
            tags.AddLast(tag);

            tag = new cRegistryTag();
            tag.ClassTypeID = new Guid("{A86D0698-27B1-4e96-9441-201E5EAB2AC2}");       // VPO_Links.DTH
            tag.ClassID = new Guid("{ABEC2D4C-1D10-464c-8782-2C4AF81B4A87}");     // DTH_Entry
            tags.AddLast(tag);

            tag = new cRegistryTag();
            tag.ClassTypeID = new Guid("{A86D0698-27B1-4e96-9441-201E5EAB2AC2}");       // VPO_Links.DTH
            tag.ClassID = new Guid("{1C1154C6-62B0-49fa-B778-B849D5B36661}");     // DTH_Status
            tags.AddLast(tag);


            return true;
        }

        /*
         * this is our take-off of a object class factory. it takes a reference to a Generic object
         * along with the GUID of the desired class. If an object is successfully created we return
         * "True" otherwise we return "False"
         * 
        */

        public override Boolean Object_Create(Guid object_id, ref Object obj)
        {
            if (object_id.Equals(new Guid("{BB897653-4AE5-4b53-9D32-14102C2190B7}")))
            {
                // create a new VPO_LinkTable
                obj = new VPO_LinkTable();
                return true;
            }
            else if (object_id.Equals(new Guid("{ABEC2D4C-1D10-464c-8782-2C4AF81B4A87}")))
            {
                // create a new VPO_LinkTable.DTH_Entry
                obj = new DataTypeHandler_Entry();
                return true;
            }
            else if (object_id.Equals(new Guid("{1C1154C6-62B0-49fa-B778-B849D5B36661}")))
            {
                // create a new VPO_LinkTable.DTH_Status
                obj = new DataTypeHandler_Status();
                return true;
            }


            return false;
        }
    }
}
