LR.sys.BaseControlSettings = {
  control: {
    domEventHandler: undefined,         // used to re-assign the control's default DOM-event handling function
    groupId: undefined,                 // TODO: incorporate GROUP logic
    memSpaceLocation: undefined,        // memShare location where button-groups are stored
    pipeEventHandler: undefined,        // used to re-assign the control's default PIPELINE-event handling function
    processPipeEvents: true,            // S/E
    state: "normal"                     // current control state (also the "init" state) (*** assumed but NOT required)
  },
  ui: {
    shellComponent: "shell",            // top-most control DOM element
    bodyComponent: "body",              // DOM element were "child" controls would be added
    visible: true,                      // (true/false/"NUI") NUI means this control has no UI elements |show(), hide()|
    storageLoc: LR.toolChest,           // non-use DOM storage location
    compoundControl: {},                // TODO
    components: {
      shell: {                          // set to "undefined" for a UI-less control
        container: undefined,           // the Parent DOM-element for this control
        element: undefined,             // DOM element
        attribute: {                    // direct mappings to the element's HTML-based attribute:value pairings
          // Examples:
          //   className: "activeFoo",
          //   title: "Hello World!",
          //   tab-index: "10"
        },
        domEvent: {
          // eventname: handler (undefined => used control.domEventHandler)
        }
      },
      body: {
        // refers to the "body" COMPONENT NAME where "child" controls would be added
      }
    }
  },
  event: {
    pipeline: {
      receive: {
        handler: undefined,             // {undefined, function} undefined = use default
        pipes: []                       // pipe(s) monitored by control
      },
      send: {
        proc: undefined,                // {undefined, function} undefined = use internal default
        pipes: []                       // pipe(s) used to Send (general) control events
      }
    },
    dom: {
      proc: undefined,                  // setting-base mechanism to Override/DELEGATE default process
// TODO: hook & hook_TEMPLATES
    },
    receive: {
      namedEvent_TEMPLATE: {
        source: "PIPE",                 // {"PIPE" or COMPONENT name}
        handler: undefined,             // event-specific handler (function)
        filter: {},                     // named attribute -> pipe : {value: Smithers, logic: "=="}
        triggeredState: undefined       // [optional] name of NEW state for the control
      },
      // all namedEvents are "callable" via the control method: doReceiveNamedEvent("NAMED_EVENT")
      namedEvent: {}                    // name:{settings}
    },
    transmit: {                         // these are the control OUTPUT event(S)
      namedEvent_TEMPLATE: {
        callback: undefined,            // callback functions execute upon this fired event
// TODO: list all "writable" event settings:
        pipeline: {
          pipeName: undefined,          // send pipe
          event: undefined,             // send event
          data: undefined               // DATA parameter of the PipeEvent
        }
      },
      // all namedEvents are "callable" via the control method: doTransmitNamedEvent("NAMED_EVENT")
      namedEvent: {}                    // name:{settings}
    }
  },
  state_TEMPLATE: {
    uiComponent_TEMPLATE: {
      container: undefined,             // Control.parent setting
      element: undefined,               // DOM element
      storageLoc: LR.toolChest,         //
      attribute: {                      // Examples:
        // className: "activeFoo",
        // title: undefined,
        // tab-index: "-1",
      },
      customSetting: {
        // storageLog: "foo",
        // customVar: "bar"
      }                                 // (EXPERIMENTAL)
    },
    uiComponent: {},                    // named UI-componet settings FOR THIS STATE
    controlAttribute: {},               // CONTROL attribute assignment
    // a FALSE return-value will incorporate the DEFAULT state-processing logic
    stateHandler: undefined,            // [optional] override delegate to handle this state-transition
    postHandler: undefined              // [optional] occurs AFTER this new state has been implemented
  },
  state: {},                            // NAMED control-state settings
}
