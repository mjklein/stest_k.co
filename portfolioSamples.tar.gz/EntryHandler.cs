﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
using System.Drawing;


using VisualInform.Plugin.Binder.VPO;
using VisualInform.Plugin.Binder.VPO.Viewer;

namespace Lib.LinkTable
{
    public partial class EntryHandler
    {
        /********************** Protected variables available to all derived classes  ***********************/
        
        protected VPO_LinkTable LinkTable;                              // holds a reference back to the VPO
        protected int EhTypeID;                                         // the id assigned to this EH (within a given binder)
        protected IBinder _Binder;                                      // ref to Binder.VPO object (via interface)

        protected static EntryDetailsViewer Viewer_EntryDetails;        // Shows the details of the entry into a grid control
        protected static Viewer EntryContentViewer;                     // Shows the "contents" of the designated link

        /**************************************** Private Methods *********************************************/

        internal EntryHandler()
        {

        }
        private void InitializeViewers()
        {
            ViewerData vci;

            // because we're in a Base class and dealing with Static viewer resources, we can ignore
            // any subsequent tries to create (base) viewers.
            if (Viewer_EntryDetails == null)
            {

                vci = LinkTable.Binder.GetViewerClassInformation(PredefinedViewerClasses.EntryDetails);
                Viewer_EntryDetails = new EntryDetailsViewer(vci, LinkTable.Binder);
            }

            if (EntryContentViewer == null)
            {
                // EH ViewerType #2: EntryContent
                // EntryContentViewer = LinkTable.Binder.VPO.CreateViewer(PredefinedViewerClasses.EntryContent);
            }
        }

        /************************************** Public Method Stubs ********************************************/

        public EntryHandler(VPO_LinkTable lt, int ehTypeId)
        {
            // member-level reference back to the LinkTable
            LinkTable = lt;
            EhTypeID = ehTypeId;

            // Initial Viewer Events
            InitializeViewers();
        }
        public virtual VPO_LinkTable.DropResponse DoDragDrop(XPathNavigator curNav, DragEventArgs e)
        {
            /*
             * DoDragDrop() is used by the vpoLinkTable to during the process of handling DragDrop events
             * within the interface. As soon as an object is dropped onto the LinkTable it calls, based upon
             * the user'strLabel preferences, the appropriate EntryHandler to take care of the event.
             * 
             * Once processing enters the EH, it has sole discretion over what to the do with the data. For example,
             * if a File handler is need, it would most likely extract the filename, its attributes and even its
             * associated icon, and then create a new node within the XML as well as the interface contol. A CustomText
             * might look into the source the dropped text and adjust it'strLabel icon accordingly, while an SQL EH might
             * not even create a node at all -- it might simply lead to some type of query update.
            */

            throw new NotImplementedException();
        }
        public virtual void ReferenceBinder(IBinder binder)
        {
            /*
            * ReferenceBinder() is used by the EH to retain a handle to the Binder.VPO itself. The binder handles all
            * of the actual writing/modifications to the XML file and, it turn, notifies all "attached" VPO'strLabel that
            * an update has been made within.
           */
            throw new NotImplementedException();
        }
        public virtual bool GetParameterValue(String param, out Object value)
        {
            /*
            * GetValue() is used in situations where a DTH doesn't necessarily "know" how to directly deal with
            * an entry's data. Since DTH's and EntryHandler's are meant to work autonomously they are not required
            * to have awareness of each other's workings. We'll use examples of two DTH's: Status and Entry.
            * The Core.Status component is completely type-agnostic (unless configured otherwise) so it doesn't need
            * to know what an entry's _ViewerClass is (nor does it care)...it simply maintains and manages a status flag as
            * assigned by the user. Core.Entry, on the ther hand, needs to render a label and an icon (and it needs to
            * know which EH to call for "launching" the entry). Those three values are entirely dependent upon
            * the EH: A Note EH would produce a completely different Label than a File; a Note EH has a fixed icon
            * whereas a File's icon is a rather complex subject. SOO, to help bridge the gap in instances such as
            * these (where a DTH's rendering of an attribute is dependent on the underlying EH), we offer the
            * function GetValue(). It allows a DTH to directly solicit a parameter from an EH. The out-only _Value
            * parameter is cast as a generic...so that in situations where the EH can actually return a _Value, that
            * _Value can be passed in a format most usable but DTH (for example, an ICON, or a String). Obviously, an
            * EH may find that it is just not able to provide a param _Value (for example, a File EH does would have
            * no way of providing a _Value for "From" ), so the bool return _Value would be False.
            * 
           */
            
            throw new NotImplementedException();
        }
        public virtual Icon GetIcon(int size, ref XPathNavigator xpnEhData)
        {
            throw new NotImplementedException();
        }
        public virtual String GetLabel(ref XPathNavigator xpnEhData)
        {
            throw new NotImplementedException();
        }
        public virtual void Open(ref XPathNavigator xpnEh, int nodeIndexPosition)
        {
            /*
             * Open is called by LinkTable whenever the user calls for the Open-ing of an entry -- usually
             * as a direct result of double-clicking the entry Label
             */

            throw new NotImplementedException();
        }
        public virtual void Select(ref XPathNavigator xpnEh, int nodeIndexPosition)
        {
            throw new NotImplementedException();
        }
        public virtual void New(Object data)
        {
            throw new NotImplementedException();
        }
        public virtual void New(XPathNavigator xpnTarget, Object dataObject)
        {
            // get the data we'll need to render the children after they've been added
            int generation = LinkTable.GetNodeGeneration(xpnTarget) + 1;
            int posLastDescendant = LinkTable.GetLastDescendentIndex(xpnTarget);
            int yPosInsert = (posLastDescendant + 1) * LinkTable.Settings.RowHeight;
            XPathNavigator xpnChildrenTag = xpnTarget.SelectSingleNode("entries");
            String visible = xpnChildrenTag.GetAttribute("visible", String.Empty);

            if (visible.Equals(String.Empty))
            {
                // Target does not have any existing children
                xpnChildrenTag.CreateAttribute("", "visible", "", "false");
                InsertNewXmlNode(xpnChildrenTag, dataObject);

                LinkTable.NodeExpand(xpnTarget);
            }
            else if (visible.ToLower().Equals("true"))
            {
                // Target has visible children; add another Child and then refresh the display
                uint newEntryID = InsertNewXmlNode(xpnChildrenTag, dataObject);

                LinkTable.NodeLoad(generation,
                                        LinkTable.GetNodeByID(newEntryID),
                                        false,
                                        yPosInsert);

                // TODO: return EntryHandler.DropResponse.RedrawTarget;
                LinkTable.RefreshDisplay();
            }
            else
            {
                // Target has children and they are currently visible
                InsertNewXmlNode(xpnChildrenTag, dataObject);
                LinkTable.NodeExpand(xpnTarget);
            }

            // save our changes
            LinkTable.Binder.Save();
        }
        public virtual void Save(Object data)
        {
            throw new NotImplementedException();
        }
        public virtual void Cut(XPathNavigator xpnTarget)
        {
            throw new NotImplementedException();
        }
        public virtual void Paste(XPathNavigator xpnTarget)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Called wheneve the User has initiated a process causing xpnTarget to be removed from Binder. XpnTarget
        /// is relocated into the RecycleBin (xml branch) where it resides until Recovered() or the Binder closes, at
        /// which time ALL files within the Binder bearing the Node's ID (id.extA, id.extB, etc.) will be permanently
        /// deleted from the Binder.
        /// 
        /// Any EH requiring special processing (like SQL-based nodes) should override this method.
        /// </summary>
        /// <param name="xpnTarget">The node that is being recycled.</param>
        /// <param name="recycleFolder">The folder name where any Temporary files can be stored pending delete.</param>
        public virtual void Recycle(XPathNavigator xpnTarget, String recycleFolder)
        {
            // do nothing
        }
        public virtual void Restore(XPathNavigator xpnTarget)
        {
            throw new NotImplementedException();
        }
        public virtual void Copy(XPathNavigator xpnTarget)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Callback stub for "IsNewResource()" that appends a child node under xpnTarget, returning its new ID."
        /// </summary>
        /// <param name="xpnTarget"></param>
        /// <param name="dataObject"></param>
        /// <returns></returns>
        protected virtual uint InsertNewXmlNode(XPathNavigator xpnTarget, Object dataObject)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Anytime a Drop event occurs, the drop-target is notified via this QueryDropTarget() method. Returning
        /// False will cancel the default process (returning True will enable it.)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="dea"></param>
        /// <returns>Unless overriden, enables the default drop handler by returning True.</returns>
        public virtual bool QueryDrop(XPathNavigator xpnTarget, Object sender, ref DragEventArgs dea)
        {
            // Since this is the base class, we're going to defer to the default Drop process...
            return true;
        }
    }
}
